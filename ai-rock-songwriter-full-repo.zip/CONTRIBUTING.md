# Contributing to AI Rock Songwriter Skill

Thank you for considering contributing to this skill! This document outlines how to contribute effectively.

## Ways to Contribute

### 1. Add New Subgenre Templates

If you have experience producing a specific rock subgenre that isn't currently covered, you can add a template.

Steps:

1. Fork the repository
2. Add your template to `skill/references/suno-prompt-templates.md`
3. Include all 9 required components
4. Test the template with at least 3 different songs in Suno
5. Submit a pull request with example outputs

Subgenre suggestions still needed:

- Psychedelic rock (1960s)
- Krautrock
- Post-punk
- Hardcore punk
- Math rock
- Blues rock
- Southern rock
- Progressive rock
- New wave
- Synthwave-rock fusion

### 2. Add New Language Support

To add support for a new language, you need to create a comprehensive rules document.

Steps:

1. Create `skill/references/[language]-lyrics-rules.md`
2. Include sections for:
   - Why this language needs special rules
   - 8-10 specific rules for AI-friendly lyrics
   - Common pitfalls
   - Subgenre-specific vocabulary considerations
   - Singability and stress patterns
   - Cultural sensitivity notes
3. Test with at least 3 songs in different subgenres
4. Update `skill/SKILL.md` to reference the new language file
5. Update `skill/references/multilingual-rules.md` with adaptation notes for the new language

Languages currently needing full rule sets:

- Spanish
- French
- German
- Italian
- Portuguese
- Japanese
- Korean
- Arabic
- Russian

### 3. Improve Existing Rules

If you've found that a rule produces suboptimal results or could be clearer, you can suggest improvements.

Steps:

1. Open an issue describing the rule and your suggested change
2. Explain why the change would improve outputs
3. Provide before/after examples if possible
4. Discussion happens in the issue thread
5. If approved, submit a pull request

### 4. Share Example Outputs

Real-world examples help validate the skill's effectiveness and inspire other users.

Steps:

1. Use the skill to produce a song
2. Add the song's complete deliverable package to `examples/`
3. Include:
   - The brief that was given
   - The complete output (titles, lyrics, style prompt, tips)
   - Notes on how Suno generated it (with links if public)
4. Submit a pull request

Examples should demonstrate:

- Different subgenres
- Different languages
- Different emotional themes
- Different reference song scenarios
- Successful and challenging cases (both are valuable)

### 5. Documentation Improvements

If you find errors, unclear explanations, or missing information in the documentation:

Steps:

1. Open an issue or submit a pull request directly
2. For pull requests, focus on one improvement per PR
3. Maintain bilingual consistency (English and Turkish) if changes affect README

## Pull Request Guidelines

### What we accept

- Subgenre template additions
- New language rule documents
- Improvements to existing rules with clear justification
- Documentation fixes and improvements
- Example outputs that demonstrate the methodology
- Workflow improvements that maintain backward compatibility

### What we don't accept

- Removal of copyright safety rules (these are non-negotiable)
- Templates that name specific artists or bands
- Changes that reduce overall skill quality
- Branded promotional content within the skill itself

### Code Review

All pull requests are reviewed for:

- Adherence to copyright safety rules
- Quality of language rules and templates
- Consistency with existing structure
- Documentation completeness
- Test coverage (provided examples)

## Code of Conduct

This project maintains a respectful, professional environment. Contributors should:

- Be welcoming to new participants
- Provide constructive feedback
- Focus on what's best for the community
- Show empathy toward others
- Acknowledge mistakes and learn from them

Unacceptable behavior:

- Harassment of any form
- Discriminatory language or actions
- Personal attacks
- Trolling or insulting comments
- Other conduct that would be inappropriate in a professional setting

## Recognition

Contributors are credited in:

- The CHANGELOG.md for their specific contributions
- The README.md if they make substantial additions
- The skill metadata if they add a complete language or major subgenre coverage

## Questions?

For questions not covered here:

- Open a GitHub issue with the "question" label
- Tag @diabolikss in the issue
- Or contact through the Diabolikss brand channels listed in README

Thank you for helping make AI music production better for everyone.
