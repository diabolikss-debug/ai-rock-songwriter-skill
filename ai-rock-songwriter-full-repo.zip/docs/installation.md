# Installing and Packaging the Skill

This document explains how to install and package the AI Rock Songwriter skill.

## For End Users: Installing the Skill

### Method 1: Direct .skill File Installation (Easiest)

1. Download the latest `ai-rock-songwriter.skill` file from the [Releases page](https://github.com/diabolikss/ai-rock-songwriter-skill/releases)
2. Open Claude.ai
3. Go to Settings > Capabilities > Skills
4. Click "Add Skill" or "Upload Skill"
5. Select the downloaded `.skill` file
6. The skill is now active

The skill will automatically activate when you ask Claude to help with rock music production.

### Method 2: Manual File Installation

If you can't use the .skill file format, you can manually set up the skill:

1. Clone the repository:
```bash
git clone https://github.com/diabolikss/ai-rock-songwriter-skill.git
```

2. Navigate to the skill directory:
```bash
cd ai-rock-songwriter-skill/skill
```

3. The structure inside `skill/` is the complete skill. Reference the `SKILL.md` file when you want Claude to use this methodology.

For paid Claude.ai accounts with skill upload features, you can upload the entire `skill/` directory.

## For Developers: Packaging the Skill

If you're contributing to this skill or building your own version, here's how to package it.

### Prerequisites

- Python 3.7+
- Access to Claude's skill packaging script (or use the manual zip method below)

### Method 1: Using Claude's Packaging Script

If you have access to the `package_skill.py` script from Anthropic:

```bash
python -m scripts.package_skill /path/to/ai-rock-songwriter/skill
```

This produces a `.skill` file ready for distribution.

### Method 2: Manual Packaging

If you don't have the official packaging script, you can manually create a `.skill` file:

```bash
cd ai-rock-songwriter
zip -r ai-rock-songwriter.skill skill/ -x "*.DS_Store" -x "*/.git/*"
```

This creates a `.skill` file from the `skill/` directory.

### Verifying the Package

A valid `.skill` file should:

- Be a ZIP archive
- Contain a `SKILL.md` file at the root or in a single top-level directory
- Have all reference and asset files in their correct subdirectories

To verify:

```bash
unzip -l ai-rock-songwriter.skill
```

Expected output should show:

- SKILL.md
- references/copyright-safety.md
- references/suno-prompt-templates.md
- references/turkish-lyrics-rules.md
- references/english-lyrics-rules.md
- references/multilingual-rules.md
- references/song-structure.md
- references/vocal-direction.md
- references/production-workflow.md
- assets/style-prompt-builder.md
- assets/song-delivery-template.md

## Updating the Skill

When the skill is updated:

1. The version number in CHANGELOG.md is incremented
2. A new `.skill` file is generated
3. A new release is created on GitHub
4. Users can re-download and replace their installed version

## Troubleshooting Installation

### Skill doesn't activate

If the skill doesn't trigger when you ask about rock music:

1. Check that the skill is enabled in Claude.ai settings
2. Try more specific prompts (e.g., "Create a grunge song using my AI music skill")
3. Check that the SKILL.md description is loaded correctly
4. Restart your Claude.ai session

### Skill file won't upload

If Claude.ai rejects the .skill file:

1. Verify the file is a valid ZIP archive
2. Verify SKILL.md is present at the expected location
3. Check that file size is under platform limits
4. Try repackaging with the manual zip method

### Skill triggers incorrectly

If the skill activates for non-music tasks:

The skill description is designed to trigger on rock music topics. If it triggers too broadly:

1. Open an issue on GitHub describing the false trigger
2. The description may need refinement in a future version

If it triggers too narrowly:

1. Use more music-related keywords in your prompts
2. Open an issue with examples

## Custom Versions

You're free to fork and customize this skill for your specific needs. Common customizations:

### Brand-Specific Version

Add your channel/brand identity to the skill so it applies your aesthetic by default:

1. Fork the repository
2. Modify `skill/SKILL.md` to include your brand identity
3. Add brand-specific sections to references
4. Repackage as `your-brand-rock-songwriter.skill`

### Subgenre-Specialized Version

If you only produce one subgenre (e.g., only doom metal), you can create a specialized version:

1. Fork the repository
2. Remove subgenre templates you don't need from `suno-prompt-templates.md`
3. Add deeper detail for your chosen subgenre
4. Repackage with descriptive name

## Contributing Your Custom Versions

If you create a useful custom version, consider:

1. Sharing it as a separate repository (link from your README to this one)
2. Or proposing improvements to the main version through pull requests

The community benefits from diverse approaches and shared learning.
