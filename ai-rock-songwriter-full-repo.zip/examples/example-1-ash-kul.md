# Example Output: "Ash" / "Kül"

This example demonstrates a complete delivery package produced using the AI Rock Songwriter skill. The song was created for The Riff Keeper YouTube channel and is presented in both Turkish ("Kül") and English ("Ash") versions.

## Original Brief

**User request:**
> "Türkçe olarak Pearl Jam Black havasında ve melankolisinde, ayrıca söz olarak yine geride kalmış ama unutulamamış bir aşk için şarkı yazman."

Translation: "Write a song in Turkish, in the mood and melancholy of Pearl Jam's 'Black', with lyrics about a love that's been left behind but cannot be forgotten."

## How the Skill Handled the Brief

### Reference song treatment

The user provided "Pearl Jam's Black" as an atmospheric reference. Following the skill's copyright safety rules:

- The artist name was not used in any output
- The song title was not used in any output
- The atmosphere was preserved (slow-burn grunge ballad, Pacific Northwest aesthetic)
- All specific imagery and metaphors were rewritten

### Title selection

The skill suggested 5 single-word titles:
1. **Kül** (Ash)
2. Sen Gittiğinden Beri (Since You Left)
3. Yarım Kalan Şarkı (Half-Finished Song)
4. Hâlâ Burada (Still Here)
5. Sen Yokken (When You're Gone)

User selected: **Kül** for direct emotional resonance and single-word strength.

## Complete Delivery

### Title

**Turkish:** Kül
**English:** Ash

### Turkish Lyrics

```
[Intro]
(instrumental, 15 seconds, slow melancholic guitar arpeggio with subtle reverb)

[Verse 1]
Saatler durdu sanki o gün
Sen kapıyı kapattığında
Bir bardak hala yarım masada
Senin dudağının izinde

Odanın kokusu hala aynı
Telefonum sustu, kalbim sustu
Ama hatıralar konuşur hala

[Pre-Chorus]
Söylemediğim her söz
Şimdi boğazımda bir taş
Göremediğim her yarın
Bir gölge bırakıyor bana

[Chorus]
Sen gittin, ben kaldım
Bu evin içinde bir yabancı gibi
Sen gittin, ben yandım
Geriye kalan sadece kül

Kül... kül... kül...
Aşkımızdan geriye

[Verse 2]
Şehirdeki o kafe hala açık
Bizim masamız boş duruyor
Yağmur yağıyor pencerede
Senin sevdiğin şarkı çalıyor

Radyoyu kapatamıyorum
Çünkü o sesi yine duyuyorum

[Chorus]
Sen gittin, ben kaldım
Bu evin içinde bir yabancı gibi
Sen gittin, ben yandım
Geriye kalan sadece kül

Kül... kül... kül...
Aşkımızdan geriye

[Bridge]
(quieter, more intimate, 20 seconds)
Belki bir gün karşılaşırız
Sen gülümsersin uzaktan
Ben başımı çeviririm
Çünkü görmek hatırlamaktan ağır

[Final Chorus - Climactic]
Sen gittin, ben kaldım!
Bu evin içinde bir yabancı gibi!
Sen gittin, ben yandım!
Geriye kalan sadece kül!

Kül... kül... kül...
Sadece kül...

[Outro]
(short instrumental fade, 25 seconds, single guitar with reverb)
Kül...
(whispered)
Sadece kül...
```

### English Lyrics (Adapted, Not Translated)

```
[Intro]
(instrumental, 15 seconds, slow melancholic guitar arpeggio with subtle reverb)

[Verse 1]
The clocks all stopped that quiet day
The moment that you closed the door
A glass still half-filled on the table
Where your lips had been before

The room still holds your scent inside
My phone went silent, so did I
But memories keep speaking still
They never let the silence lie

[Pre-Chorus]
Every word I never said
Sits like a stone inside my throat
Every tomorrow I won't see
Casts a shadow where I float

[Chorus]
You left, I stayed behind
A stranger in my own four walls
You left, I burned alive
And all that's left is ash that falls

Ash... ash... ash...
From everything we were

[Verse 2]
That cafe in the city's still alive
Our table sits there empty now
The rain is falling on the window
Your favorite song still plays somehow

I cannot turn the radio off
Because I hear your voice again

[Chorus]
You left, I stayed behind
A stranger in my own four walls
You left, I burned alive
And all that's left is ash that falls

Ash... ash... ash...
From everything we were

[Bridge]
(quieter, more intimate, 20 seconds)
Maybe one day on some street
You'll smile at me from far away
I'll turn my head and look elsewhere
'Cause seeing hurts more than memory's weight

[Final Chorus - Climactic]
You left, I stayed behind!
A stranger in my own four walls!
You left, I burned alive!
And all that's left is ash that falls!

Ash... ash... ash...
Only ash remains...

[Outro]
(short instrumental fade, 25 seconds, single guitar with reverb)
Ash...
(whispered)
Only ash...
```

### Suno Style Prompt (Turkish Version)

```
Slow burning grunge ballad, early 1990s Pacific Northwest sound, melancholic and 
emotionally devastating, clean arpeggiated guitar intro with subtle reverb building 
into distorted crescendo, mid-tempo around 80 bpm, baritone male vocals with raw 
emotional weight and vulnerability, vocals start hushed and intimate then build to 
anguished cathartic climax, prominent bass guitar with melodic counterpoint, drums 
minimal in verses then heavier in choruses, classic rock instrumentation no 
synthesizers, lo-fi analog warmth, loud-quiet-loud dynamic structure, four-minute 
song structure with concise emotional outro, Turkish language vocals, gritty rough 
male vocals with vocal cracks and emotional strain not polished, themes of lost 
love and lingering memory, cathartic and heartbreaking mood, focused song structure 
no extended jams
```

### Suno Style Prompt (English Version)

```
Slow burning grunge ballad, early 1990s Pacific Northwest sound, melancholic and 
emotionally devastating, clean arpeggiated guitar intro with subtle reverb building 
into distorted crescendo, mid-tempo around 80 bpm, baritone male vocals with raw 
emotional weight and vulnerability, vocals start hushed and intimate then build to 
anguished cathartic climax, prominent bass guitar with melodic counterpoint, drums 
minimal in verses then heavier in choruses, classic rock instrumentation no 
synthesizers, lo-fi analog warmth, loud-quiet-loud dynamic structure, four-minute 
song structure with concise emotional outro, English language vocals, gritty rough 
male vocals with vocal cracks and emotional strain not polished, themes of lost 
love and lingering memory, cathartic and heartbreaking mood, focused song structure 
no extended jams
```

### Production Tips

**Vocal Persona:**
This was the first song for The Riff Keeper. After generating, the best vocal performance was saved as the channel's primary Persona for vocal consistency in future songs.

**Suno Mode:**
Custom Mode used. Lyrics pasted in Lyrics field, style prompt in Style of Music field.

**Generation Variations:**
6 variations were generated. The 4th variation had the best emotional vocal delivery and was selected for production.

**Common Issue Resolution:**
First two generations were over 5 minutes. Adding "focused song structure no extended jams" to the style prompt brought subsequent generations to 4:00-4:15 range consistently.

**Vocal Tone:**
The first three generations had a too-polished pop quality. Adding "gritty rough male vocals with vocal cracks and emotional strain, not polished" produced the desired raw emotional quality.

**Bridge Quality:**
The bridge consistently came out strong because of the explicit "(quieter, more intimate, 20 seconds)" inline guidance.

### Reference Notes

**Reference provided:** Pearl Jam's "Black" (atmosphere only, no lyrics or specific elements)

**What was preserved:**
- Slow-burn grunge ballad pacing
- Early 1990s Pacific Northwest atmospheric quality
- Loud-quiet-loud dynamic structure
- Baritone male vocal character with emotional vulnerability
- Mid-tempo around 80 bpm
- Build-and-release emotional structure

**What was rewritten:**
- All lyrics are entirely original
- Central metaphor changed (Black uses different imagery; Kül uses ash and burning as central metaphor)
- All specific imagery is original (the empty chair, half-finished glass, silent phone)
- Chorus hook structure is original ("Sen gittin, ben kaldım")
- Outro structure is original

### Adaptation Notes (Turkish to English)

The Turkish version is the original. The English version is an adaptation that preserves meaning, atmosphere, and emotional weight while flowing naturally in English.

**Key adaptation choices:**

- Title "Kül" adapted to "Ash" for direct semantic equivalent
- Chorus rhyme scheme rebuilt: Turkish suffix-based rhyme replaced with English "walls/falls" rhyme
- Verse 2 specific Turkish café imagery generalized but kept atmospheric
- Bridge meaning preserved with natural English phrasing
- Outro repetition pattern preserved

### Copyright Verification

This song was written following all copyright safety rules:

- No artist or band names appear in lyrics, title, or style prompt
- All metaphors and imagery are original
- Reference song "Black" was used only for atmospheric direction; all specific imagery, metaphors, and lyrical hooks are completely rewritten
- Title "Kül" is original and does not match any known song
- Chorus hook "Sen gittin, ben kaldım" is original and does not echo any famous chorus

The song is safe for commercial release on AI music platforms with appropriate Suno Pro license documentation.

## Why This Example Matters

This example demonstrates several key methodology principles:

1. **Reference song handling:** A famous song was used as inspiration without violating copyright. Atmosphere preserved, content originalized.

2. **Bilingual production:** Same song produced in two languages through adaptation, not translation.

3. **Single-word title strategy:** "Kül" / "Ash" works in both languages and provides strong branding.

4. **Suno-specific optimization:** Style prompt addresses Suno's tendencies (duration drift, polish bias, bridge weakness).

5. **Channel consistency:** Established the vocal Persona used across The Riff Keeper's catalog.

This methodology can be applied to any rock subgenre, any reference inspiration, and any language combination supported by AI music tools.
