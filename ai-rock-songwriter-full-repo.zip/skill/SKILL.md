---
name: ai-rock-songwriter
description: "Use this skill whenever the user wants to create rock music songs using AI tools like Suno or Udio. Triggers include any mention of writing rock lyrics, generating AI rock songs, creating songs for a YouTube music channel, building a music brand with AI-generated rock tracks, or producing songs in subgenres like classic rock, hard rock, doom, stoner, grunge, punk, post-rock, alternative, or indie rock. Also use when users ask for Suno/Udio prompt engineering help, copyright-safe AI music production guidance, lyrics in Turkish or English (or other supported languages), or when adapting one song into multiple languages. This skill ensures professional, copyright-safe, well-structured AI rock music production from concept to final Suno-ready package."
license: MIT
---

# AI Rock Songwriter

A complete framework for producing copyright-safe, professional AI-generated rock music songs using tools like Suno AI or Udio. This skill guides Claude through the full songwriting workflow: from concept and theme analysis to final delivery of lyrics, style prompts, and production guidance.

## Overview

This skill is built around six core principles that ensure AI-generated rock music is professional, legally safe, and emotionally authentic:

1. **Copyright safety first.** Never reference specific artists, bands, or songs in any output that goes to the AI generator.
2. **Era and atmosphere over imitation.** Inspire from time periods, geographies, and moods rather than copying styles.
3. **Structured songwriting.** Use proven song structures with clear timing for the 4-minute commercial format.
4. **Multi-language adaptation, not translation.** When producing songs in multiple languages, adapt meaning and emotion rather than translating word-for-word.
5. **Detailed Suno prompt engineering.** Provide style prompts that include genre, era, tempo, vocal description, instruments, dynamics, duration, language, and mood.
6. **Production-ready delivery.** Always deliver a complete package: title options, full lyrics with structure tags, style prompt, and production tips.

## Quick Reference

| Task | Action |
|------|--------|
| Receive song request | Confirm theme, atmosphere, language, reference (if any) |
| Provide title options | Offer 3-5 single-word or short title suggestions |
| Write lyrics | Use Suno structure tags, follow language-specific rules |
| Generate style prompt | Include 9 required components (see below) |
| Deliver package | Lyrics + style prompt + production tips |

## When to Use This Skill

This skill activates whenever a user wants to:

- Create an original rock song using AI music generators
- Write lyrics in the rock genre with proper structure
- Generate Suno-ready or Udio-ready style prompts
- Produce songs in multiple languages (Turkish, English, or other supported languages)
- Build a YouTube music channel with AI-generated rock content
- Receive copyright-safe production guidance for AI music

## Core Workflow

### Step 1: Capture the Brief

When a user requests a new song, gather these details before writing:

- **Theme:** What is the song about? (loss, longing, anger, hope, etc.)
- **Atmosphere/reference:** Any specific mood or reference song? (Note: reference songs are used for atmosphere only, never copied)
- **Language(s):** Turkish, English, or another supported language? Will both versions be needed?
- **Subgenre:** Classic rock, grunge, doom, post-rock, etc.?
- **Duration target:** Default is 4 minutes (3:50-4:10) unless specified otherwise

If the user provides a reference song (e.g., "in the mood of [Song X]"), explicitly note that the output will preserve only musical atmosphere and structure, never specific lyrics, metaphors, or imagery from the reference.

### Step 2: Suggest Titles

Offer 3-5 title options. Strong titles tend to be:

- Single words (e.g., "Ash", "Static", "Stone")
- Strong nature elements or abstract concepts
- Memorable and easy to search for
- Adaptable across languages

For multilingual projects, suggest title equivalents in each language (e.g., Turkish "Kül" → English "Ash").

### Step 3: Write Lyrics

Always use Suno structure tags. Follow language-specific rules in references:

- For Turkish lyrics: see `references/turkish-lyrics-rules.md`
- For English lyrics: see `references/english-lyrics-rules.md`
- For other languages: see `references/multilingual-rules.md`

Standard 4-minute song structure:

```
[Intro] - 15-20 seconds instrumental
[Verse 1] - 30-40 seconds, 6-8 lines
[Pre-Chorus] - 15-20 seconds, 4 lines
[Chorus] - 25-35 seconds, 4-6 lines
[Verse 2] - 30-40 seconds, 6-8 lines
[Pre-Chorus] - optional repeat
[Chorus] - repeat
[Bridge] - 20-25 seconds, quieter and intimate
[Final Chorus - Climactic] - 25-35 seconds
[Outro] - 25-35 seconds instrumental fade
```

For detailed structure guidance, see `references/song-structure.md`.

### Step 4: Generate Style Prompt

The style prompt is critical for Suno/Udio output quality. Always write in English (these tools perform best with English commands).

Required components:

1. **Genre and subgenre** (e.g., "atmospheric mid-tempo rock ballad", "stoner doom")
2. **Era and atmosphere** (e.g., "early 1990s Pacific Northwest grunge", "1970s desert rock vibe")
3. **Tempo** in BPM (e.g., "around 80 bpm")
4. **Vocal description** (e.g., "baritone male vocals with rich resonance, gritty and emotional, not polished")
5. **Instrument set** (specific instruments to use)
6. **Dynamic structure** (e.g., "loud-quiet-loud", "build-and-release", "slow burn crescendo")
7. **Duration instruction** (e.g., "four-minute song structure, focused song no extended jams")
8. **Language** (e.g., "Turkish language vocals", "English language vocals")
9. **Theme/mood** (e.g., "themes of lost love and lingering memory")

Never include specific artist or band names in the style prompt.

For detailed prompt templates by subgenre, see `references/suno-prompt-templates.md`.

### Step 5: Multi-Language Adaptation

When producing the same song in multiple languages:

- The second language version is an **adaptation**, not a translation.
- Preserve meaning, atmosphere, and emotional weight.
- Adapt to the natural flow, rhyme, and rhythm of the target language.
- Title adaptation finds either an equivalent meaning or a stronger word in the target language.

For detailed adaptation guidance, see `references/multilingual-rules.md`.

### Step 6: Deliver the Package

Every song delivery includes:

1. **3-5 title suggestions** with explanations of why each works
2. **Full lyrics** with Suno structure tags
3. **Suno style prompt** in English (one for each language version)
4. **Production tips** specific to the song (e.g., vocal tone notes, expected challenges)
5. **Copyright check confirmation** stating that no reference material was directly copied

## Critical Rules

### Copyright Safety (Non-Negotiable)

These rules apply at every step. See `references/copyright-safety.md` for the full guide.

- Never write a specific artist or band name into any output that the user will paste into Suno or Udio
- Never use phrases like "in the style of [Artist]", "sounds like [Artist]", or "[Artist]-inspired" in style prompts
- When the user provides a reference song, explicitly preserve only the musical atmosphere and structural feel; rewrite all metaphors, imagery, and specific phrasings
- After writing lyrics, perform a similarity check against any provided reference song; if any line, metaphor, or image is too close, rewrite it
- Recommend that the user maintain a Pro/commercial license for their chosen AI music platform and archive license documentation

### Vocal Consistency Across a Channel

For users building a music channel:

- Recommend using the same Suno Persona across all songs to create a cohesive "single artist" feel
- The first song establishes the vocal identity; subsequent songs reference that Persona
- Note this in production tips when delivering songs

### Duration Control

Suno often misjudges duration. To enforce 4-minute targets:

- Always include "four-minute song structure, focused song no extended jams" in the style prompt
- For Outro sections, add inline timing: `[Outro] (very short fade, 25 seconds maximum)`
- For Bridge sections: `[Bridge] (brief, 20 seconds)`
- If the first generation is too long, shorten Verse 2 or remove the second Pre-Chorus

## Reference Files

This skill includes detailed references for specific situations:

- `references/copyright-safety.md` - Comprehensive copyright safety rules and examples
- `references/song-structure.md` - Detailed structure breakdown with timing for each section
- `references/suno-prompt-templates.md` - Pre-written style prompts for 10+ rock subgenres
- `references/turkish-lyrics-rules.md` - Turkish songwriting rules (no inverted sentences, character simplification, etc.)
- `references/english-lyrics-rules.md` - English songwriting rules (rhyme schemes, conversational tone, etc.)
- `references/multilingual-rules.md` - Adaptation methodology for songs in multiple languages
- `references/vocal-direction.md` - How to describe vocal styles for AI generators
- `references/production-workflow.md` - End-to-end production workflow from concept to upload

## Assets

- `assets/style-prompt-builder.md` - Fillable template for constructing style prompts step by step
- `assets/song-delivery-template.md` - Template for the final delivery package format

## Supported Languages

Primary support: English, Turkish

Secondary support (with care for AI generator compatibility): Spanish, French, German, Italian, Portuguese

For language-specific notes, see `references/multilingual-rules.md`.

## Philosophy

Great AI rock music isn't about replacing human creativity, it's about amplifying it. This skill helps producers focus on the parts of songwriting that matter most: emotion, theme, narrative, and atmosphere. The AI handles execution; the producer brings vision and curation.

A song made through this skill should feel like a genuine rock song, not an AI gimmick. That's why every step prioritizes craft over speed, originality over imitation, and emotional truth over technical novelty.

## Credits and Brand

This skill is created and maintained by Diabolikss. Original development and curation by the Diabolikss brand, focused on bringing professional AI music production methodology to independent creators worldwide.

For real-world examples of songs produced using this methodology, see the example projects referenced in the GitHub repository documentation.
