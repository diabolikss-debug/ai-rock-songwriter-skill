# Song Delivery Template

This template defines the standard format for delivering a complete AI rock song package to a user. Following this format ensures the user receives everything needed to produce the song.

## Standard Delivery Structure

Every song delivery should include these five components in order:

1. **Title Suggestions**
2. **Full Lyrics with Structure Tags**
3. **Style Prompt(s)**
4. **Production Tips**
5. **Copyright Confirmation**

## Component 1: Title Suggestions

Provide 3-5 title options. For each title, briefly explain why it works.

### Format:

```
## Title Suggestions

**1. [Title Option 1]**
[Brief explanation of why this title fits the song]

**2. [Title Option 2]**
[Brief explanation]

**3. [Title Option 3]**
[Brief explanation]

[Optional: 4 and 5]

**Recommendation: [Your top suggestion]**
[Reason why you recommend this one]
```

### Example:

```
## Title Suggestions

**1. Ash**
Single word, strong emotional weight, directly references the song's central metaphor of things burning down. Memorable and easy to search.

**2. What Remains**
More narrative, captures the question the song asks. Stronger lyrically but less catchy.

**3. Embers**
The stage before ash, suggests there's still something glowing. More hopeful interpretation.

**Recommendation: Ash**
Single-word titles work better for AI music branding, and "Ash" resonates with the song's emotional core directly.
```

## Component 2: Full Lyrics with Structure Tags

Provide complete lyrics with all Suno structure tags. If multilingual, provide each version separately.

### Format:

```
## Lyrics

### [Language Version Title]

[Full lyrics with structure tags]
```

### Example:

```
## Lyrics

### Ash (English Version)

[Intro]
(instrumental, 15 seconds, slow melancholic guitar arpeggio with subtle reverb)

[Verse 1]
The clocks all stopped that quiet day
The moment that you closed the door
A glass still half-filled on the table
Where your lips had been before

The room still holds your scent inside
My phone went silent, so did I
But memories keep speaking still
They never let the silence lie

[Pre-Chorus]
Every word I never said
Sits like a stone inside my throat
Every tomorrow I won't see
Casts a shadow where I float

[Chorus]
You left, I stayed behind
A stranger in my own four walls
You left, I burned alive
And all that's left is ash that falls

[continuing through full structure...]

[Outro]
(short instrumental fade, 25 seconds, single guitar with reverb)
Ash...
(whispered)
Only ash...
```

## Component 3: Style Prompt(s)

Provide a complete Suno-ready style prompt for each language version. Use a code block for easy copying.

### Format:

```
## Suno Style Prompt

### For [Language] Version:

​```
[Complete style prompt in English, with all 9 components]
​```
```

### Example:

```
## Suno Style Prompt

### For English Version:

​```
Atmospheric mid-tempo rock ballad, post-grunge sound from early 2000s, 
melancholic and introspective mood, clean arpeggiated guitar intro with 
subtle reverb and chorus effect, slow burn dynamic with gradual emotional 
build, mid-tempo around 88 bpm, baritone male vocals with rich resonance 
and emotional depth, vocals soulful and slightly haunting with smooth melodic 
phrasing, prominent bass guitar with melodic lines, drums steady and 
contemplative in verses with controlled crescendo in choruses, melodic 
electric guitar lead in bridge section with hauntingly beautiful tone, 
classic rock instrumentation with atmospheric reverb, four-minute song 
structure with extended emotional outro, English language vocals, 
themes of lost love and lingering memory, contemplative and 
emotionally weighted mood, focused song no extended jams
​```
```

## Component 4: Production Tips

Provide 3-7 specific tips relevant to this song. These should address:

- Likely Suno generation challenges
- Recommended Persona usage
- Vocal direction notes
- Suno mode settings
- Variation generation strategy
- Any special considerations

### Format:

```
## Production Tips

**[Tip Category]:**
[Specific guidance]

**[Tip Category]:**
[Specific guidance]

[etc.]
```

### Example:

```
## Production Tips

**Vocal Persona:**
If you have an established Persona from previous songs, use it for vocal consistency. 
If this is a first song, generate 4-6 variations and save the best vocal as a Persona 
for future use.

**Suno Mode:**
Use Custom Mode (not Quick). Paste lyrics in the Lyrics field, paste style prompt 
in the Style of Music field.

**Generation Variations:**
Generate 4-6 variations. The first generation rarely produces the perfect result. 
Listen to each in full before selecting.

**Common Issue: Duration:**
If the song generates over 4:30, regenerate with stronger duration instruction. 
The phrase "focused song no extended jams" is included in the prompt to help.

**Vocal Tone Adjustment:**
If the vocal sounds too polished or pop-styled, regenerate or add to style prompt: 
"raw unpolished vocal delivery, vocal cracks acceptable, deliberately imperfect"

**Bridge Quality:**
The bridge is the song's emotional pivot. If Suno's bridge feels rushed or generic, 
use the Extend feature to lengthen it with more melodic guitar work.
```

## Component 5: Copyright Confirmation

Confirm explicitly that copyright safety has been verified.

### Format:

```
## Copyright Verification

[Confirmation statement]
```

### Example:

```
## Copyright Verification

This song has been written following copyright safety rules:

- No artist or band names in lyrics, title, or style prompt
- All metaphors and imagery are original
- Reference song [if applicable] used only for atmospheric direction; all 
  specific imagery, metaphors, and lyrical hooks have been completely rewritten
- Title is original and does not match any known song
- Chorus hook is original and does not echo any famous chorus

The song is safe for commercial release on AI music platforms with appropriate 
license documentation.
```

## Optional Component: Reference Notes

If the user provided a reference song, include a brief note explaining what was preserved and what was changed.

### Format:

```
## Reference Notes

**Reference provided:** [Reference song or atmosphere]

**What was preserved:**
- [Element 1: e.g., "mid-tempo dynamic feel"]
- [Element 2: e.g., "post-grunge atmospheric production"]
- [Element 3: e.g., "build-and-release emotional structure"]

**What was rewritten:**
- [Element 1: e.g., "central metaphor (changed from X to Y)"]
- [Element 2: e.g., "all specific imagery and phrasing"]
- [Element 3: e.g., "chorus hook structure"]
```

## Optional Component: Multilingual Notes

If producing the song in multiple languages, include notes on adaptation choices.

### Format:

```
## Adaptation Notes

The [Language A] version and [Language B] version share the same musical structure, 
emotional core, and atmosphere, but the lyrics are adapted (not translated) to fit 
each language's natural flow.

Key adaptation choices:
- [Choice 1: e.g., "Title 'Kül' adapted to 'Ash' for direct semantic equivalent"]
- [Choice 2: e.g., "Chorus rhyme scheme rebuilt: Turkish suffix-based rhyme replaced with English 'walls/falls' rhyme"]
- [Choice 3: e.g., "Cultural reference adjusted: specific Turkish café image generalized to universal coffee shop"]
```

## Complete Delivery Example

Here's what a complete delivery looks like end-to-end:

```markdown
# [Song Name] - Complete Production Package

## Title Suggestions
[3-5 titles with explanations]

## Lyrics

### [Title] (Turkish Version)
[Full Turkish lyrics with structure tags]

### [Title] (English Version)
[Full English lyrics with structure tags]

## Suno Style Prompts

### For Turkish Version:
[Complete style prompt in code block]

### For English Version:
[Complete style prompt in code block]

## Production Tips
[6-8 specific tips]

## Adaptation Notes
[Notes on multilingual choices]

## Copyright Verification
[Explicit confirmation]
```

## Quality Standards

Every delivery should:

1. Be complete (all 5 standard components present)
2. Be properly formatted for easy copying
3. Use code blocks for prompts (single-line copy)
4. Apply all language-specific rules
5. Pass all copyright safety checks
6. Include any optional components when relevant (reference notes, multilingual notes)

## Final Delivery Checklist

Before sending the package to the user:

- [ ] Title suggestions provided (3-5 options with explanations)
- [ ] Recommended title clearly indicated
- [ ] Full lyrics with all structure tags
- [ ] Lyrics include inline timing where relevant (e.g., "[Outro] (very short, 20 seconds)")
- [ ] Style prompt complete with all 9 components
- [ ] Style prompt in code block for easy copying
- [ ] Production tips address likely challenges
- [ ] Production tips include Suno mode and variation guidance
- [ ] Copyright verification stated explicitly
- [ ] If multilingual, both versions delivered
- [ ] If reference song was provided, reference notes included
- [ ] Format is clean and professional

If all checked, the delivery is ready.
