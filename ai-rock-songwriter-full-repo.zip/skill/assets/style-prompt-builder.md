# Style Prompt Builder Template

This is a fillable template for constructing Suno/Udio style prompts step by step. Fill in each component, then assemble into the final prompt.

## The 9 Required Components

### Component 1: Genre and Subgenre

What is the song's primary genre and any specific subgenre?

```
[Your input: e.g., "atmospheric mid-tempo rock ballad" or "stoner doom" or "post-grunge"]
```

### Component 2: Era and Atmosphere

What time period and geographic/cultural scene are you referencing?

```
[Your input: e.g., "early 1990s Pacific Northwest grunge" or "1970s desert rock" or "early 2000s post-grunge"]
```

### Component 3: Tempo

What's the BPM target? (See tempo guide in suno-prompt-templates.md)

```
[Your input: e.g., "around 88 bpm" or "slow tempo 65 bpm" or "driving 130 bpm"]
```

### Component 4: Vocal Description

Range, gender, texture, delivery style, emotional quality. (See vocal-direction.md for detailed templates)

```
[Your input: e.g., "baritone male vocals with rich resonance and emotional depth, slightly haunting, soulful melodic phrasing"]
```

### Component 5: Instrument Set

What instruments should dominate the production?

```
[Your input: e.g., "clean arpeggiated guitar intro, prominent bass with melodic counterpoint, steady drums, melodic guitar lead in bridge, classic rock instrumentation no synthesizers"]
```

### Component 6: Dynamic Structure

How should the song's energy shape over time?

```
[Your input: e.g., "loud-quiet-loud dynamic structure" or "build-and-release dynamic" or "slow burn crescendo with explosive climax"]
```

### Component 7: Duration Instruction

How long should the song be?

```
[Your input: e.g., "four-minute song structure with extended emotional outro, focused song no extended jams"]
```

### Component 8: Language

What language(s) for the vocals?

```
[Your input: e.g., "Turkish language vocals" or "English language vocals"]
```

### Component 9: Theme and Mood

What's the emotional content and atmosphere?

```
[Your input: e.g., "themes of lost love and lingering memory, melancholic and emotionally devastating mood"]
```

## Assembly Template

Once all 9 components are filled, assemble using this structure:

```
[Component 1: Genre/subgenre], [Component 2: Era/atmosphere], [Component 9 partial: mood], 
clean arpeggiated guitar intro [if applicable], [Component 3: Tempo], 
[Component 4: Vocal description], [Component 5: Instruments], 
[Component 6: Dynamic structure], [Component 7: Duration instruction], 
[Component 8: Language] vocals, [Component 9: Theme details]
```

## Example: Filled Template

Let me show you a complete example:

### Components filled:

1. **Genre:** atmospheric mid-tempo rock ballad
2. **Era:** early 2000s post-grunge sound
3. **Tempo:** around 88 bpm
4. **Vocals:** baritone male vocals with rich resonance and emotional depth, soulful and slightly haunting with smooth melodic phrasing
5. **Instruments:** clean arpeggiated guitar intro with subtle reverb, prominent bass guitar with melodic lines, drums steady and contemplative in verses with controlled crescendo in choruses, melodic electric guitar lead in bridge section
6. **Dynamics:** slow burn dynamic with gradual emotional build, build-and-release structure
7. **Duration:** four-minute song structure with extended emotional outro, focused song no extended jams
8. **Language:** English language vocals
9. **Theme:** themes of internal stagnation and self-confrontation, contemplative and emotionally weighted mood

### Assembled prompt:

```
Atmospheric mid-tempo rock ballad, early 2000s post-grunge sound, melancholic and 
introspective mood, clean arpeggiated guitar intro with subtle reverb, slow burn 
dynamic with gradual emotional build, mid-tempo around 88 bpm, baritone male 
vocals with rich resonance and emotional depth, vocals soulful and slightly 
haunting with smooth melodic phrasing, prominent bass guitar with melodic lines, 
drums steady and contemplative in verses with controlled crescendo in choruses, 
melodic electric guitar lead in bridge section, classic rock instrumentation 
with atmospheric reverb, four-minute song structure with extended emotional outro, 
English language vocals, themes of internal stagnation and self-confrontation, 
contemplative and emotionally weighted mood, build-and-release dynamic structure, 
focused song no extended jams
```

## Optimization Notes

After assembling your prompt:

### Length check:
- Minimum: 50 words (provides enough direction)
- Optimal: 80-120 words (clear without overwhelming)
- Maximum: 150 words (more becomes counterproductive)

### Specificity check:
- Are there at least 3 specific descriptors (e.g., "fuzz tone", "tape texture", "downtuned guitars")?
- Are there at least 2 atmospheric references (era, geography, scene)?

### Copyright check:
- Zero artist or band names
- Zero specific song or album titles
- Zero phrases like "in the style of"

### Coherence check:
- Do all components support the same overall feel?
- Are there any contradictions (e.g., "raw lo-fi" + "polished modern production")?

### Customization tips:

If you've used this prompt for previous songs and want subtle variation, adjust ONE element:
- Shift tempo by 5 BPM
- Move era reference (e.g., "early 1990s" → "mid 1990s")
- Adjust dynamic descriptor

Don't change everything at once or you lose the channel's sonic identity.

## Quick-Fill Checklist

For experienced users, here's a rapid checklist:

- [ ] Genre and subgenre specified
- [ ] Era and atmosphere specified
- [ ] BPM included
- [ ] Vocal description includes range, gender, texture, delivery
- [ ] At least 3 specific instruments mentioned
- [ ] Dynamic structure named (loud-quiet-loud, build-release, etc.)
- [ ] Duration instruction included
- [ ] Language specified
- [ ] Theme and mood described
- [ ] No artist names anywhere
- [ ] No "in the style of" phrases
- [ ] Total length 80-120 words
- [ ] No internal contradictions

If all checked, the prompt is ready to paste into Suno or Udio.
