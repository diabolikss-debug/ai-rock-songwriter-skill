# Copyright Safety Guide

This document outlines the strict copyright safety rules that apply to every output produced through this skill. These rules are non-negotiable and protect both the user and their channel from legal and platform-related risks.

## Why This Matters

In 2026, AI-generated music platforms like YouTube, Spotify, and SoundCloud have implemented strict policies regarding:

- AI-generated content disclosure
- Imitation of specific artists or songs
- Unauthorized use of artist voices, melodies, or lyrical structures
- Content ID matching against existing copyrighted works

A single careless prompt can result in monetization loss, channel demonetization, content removal, or in rare cases, legal action. Following these rules ensures your AI music remains safe to monetize and distribute.

## The Three Absolute Rules

### Rule 1: Never Use Artist or Band Names

This rule applies to:

- Lyrics (no name-dropping in song content)
- Song titles (no titles like "A Song for Pearl Jam")
- Style prompts for Suno/Udio (no "in the style of [Artist]")
- Video tags and descriptions (no using artist names as keywords)
- Promotional materials (no implying the song sounds like a specific artist)

The reasoning is simple: AI generators may produce content that mirrors the named artist's style, voice, or signature elements. Even if the AI doesn't, the act of naming creates a clear chain of intent that platforms and rights holders can use as evidence.

### Rule 2: Reference Eras, Geographies, and Atmospheres Instead

Replace artist references with descriptive alternatives:

| Instead of | Use |
|-----------|-----|
| "Pearl Jam style" | "early 1990s Pacific Northwest grunge atmosphere" |
| "Audioslave vibe" | "early 2000s post-grunge sound with melodic depth" |
| "Black Sabbath inspired" | "1970s heavy doom metal with downtuned guitars" |
| "Radiohead-like" | "atmospheric British alternative rock with electronic textures" |
| "Cure tribute" | "1980s post-punk with reverb-heavy guitars and gothic mood" |

This approach has two advantages: it's legally safe, and it produces more original output because the AI isn't trying to imitate a specific signature.

### Rule 3: Rewrite All Specific Imagery from Reference Songs

When a user provides a reference song (e.g., "I want something in the mood of [Song X]"), the output preserves only:

- Musical atmosphere
- Tempo range
- Dynamic structure (loud-quiet-loud, slow burn, etc.)
- General emotional weight

The output never preserves:

- Specific metaphors used in the reference
- Distinctive imagery (e.g., if the reference uses "stones" as a central metaphor, your output uses something different)
- Sentence structures that mirror the reference
- Lyrical hooks that echo the reference

Example workflow when given a reference song:

1. Identify the reference's core metaphor (e.g., "waiting like a stone")
2. Identify the emotional theme (e.g., "stillness due to longing")
3. Build a new metaphor that captures the same emotion (e.g., "magnetic pull holding me in place")
4. Build entirely new imagery around the new metaphor
5. After drafting lyrics, scan for any accidental similarity to the reference; rewrite if found

## Similarity Check Process

Before delivering any lyrics, run this mental checklist:

1. **Title check:** Is the title too close to a known song? If yes, choose a different title.
2. **Metaphor check:** Are any central metaphors identical or very close to the reference? If yes, rewrite.
3. **Phrase check:** Does any line use a distinctive phrase from the reference? If yes, rewrite.
4. **Structure check:** Does the lyrical narrative follow the reference's exact emotional arc? If yes, vary it.
5. **Hook check:** Does the chorus hook echo the reference's chorus? If yes, write a new hook.

If any check raises concerns, rewrite before delivery.

## Style Prompt Safety

The style prompt is what gets pasted into Suno or Udio. This is the highest-risk surface for copyright issues. Apply these specific rules:

### Never Include

- Artist names (any form, even abbreviations or nicknames)
- Specific song titles
- Phrases like "sounds like", "in the style of", "à la", "channeling"
- Album titles
- Producer names (e.g., "Rick Rubin production style")
- Studio names that are tied to specific artists

### Always Include Instead

- Decade or era ("1990s", "early 2000s", "mid-1970s")
- Geographic scene ("Pacific Northwest", "British rock", "Anatolian rock")
- Subgenre with technical detail ("post-grunge", "stoner doom", "shoegaze")
- Production aesthetic ("warm analog tape", "lo-fi garage production")
- Vocal style description (without naming a specific singer)

## Vocal Imitation Risks

AI music generators can sometimes produce vocals that sound similar to specific artists, even without being prompted to do so. To minimize this risk:

- Describe vocals using technical terms (range, texture, delivery style)
- Avoid signature vocal tropes tied to specific singers
- Use general descriptors: "baritone male", "raspy", "smooth tenor", "raw and emotional"
- Never reference specific vocal qualities from named artists

If a generated track happens to sound very similar to a known artist, the user should regenerate with adjusted prompts rather than publishing it.

## Lyrical Hooks and Choruses

Choruses are the highest-recognition part of a song. Apply extra caution:

- The chorus hook must be entirely original
- Avoid common chorus patterns from famous songs (e.g., the specific cadence of well-known chorus structures)
- Test the chorus by saying it out loud; if it instantly reminds you of an existing song, rewrite it
- Original isn't the same as obscure; clear and memorable is fine, identical is not

## What If the AI Output Sounds Too Similar?

Even with safe prompts, the AI may produce output that resembles a known song. This is rare but possible. Recommended response:

1. Regenerate the song with adjusted style prompts
2. Vary the tempo by 5-10 BPM
3. Adjust the era reference (e.g., "late 1990s" instead of "early 1990s")
4. If the issue persists, change a structural element (e.g., shift from build-and-release to loud-quiet-loud)
5. As a last resort, request a different vocal Persona

Never publish a track that sounds too similar to a known song, even if the prompt was technically safe.

## Documentation and Licensing

For every song produced:

- Note the AI tool used (Suno, Udio, etc.)
- Note the subscription tier (commercial license required for monetized use)
- Save the style prompt used
- Save the final lyrics
- Archive a screenshot or PDF of the AI tool's commercial license terms at time of generation

This documentation protects the user in case of any future copyright dispute.

## Platform Disclosure

Always recommend that the user:

- Mark videos as containing AI-generated content on YouTube
- Include AI disclosure in the video description
- Be transparent about the production process

In 2026, transparency is not just policy compliance; it's also good practice for audience trust. AI music creators who are open about their methods tend to build stronger communities than those who hide it.

## Summary Checklist

Before delivering any song:

- [ ] No artist or band names anywhere in the output
- [ ] All references are to eras, geographies, or atmospheres
- [ ] If a reference song was provided, all metaphors and imagery are completely new
- [ ] Title doesn't match any known song
- [ ] Chorus hook is original and doesn't echo famous choruses
- [ ] Style prompt follows safe construction rules
- [ ] Production tips include reminder about commercial license documentation
