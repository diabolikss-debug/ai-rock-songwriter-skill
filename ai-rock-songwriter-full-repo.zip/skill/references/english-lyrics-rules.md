# English Lyrics Rules

This document outlines best practices for writing English-language rock lyrics that work well with AI music generators. While English is generally well-supported by Suno and Udio, certain craft principles ensure professional, emotionally authentic output.

## English Advantages

English benefits from:

- Native AI training (most AI models are trained primarily on English)
- Extensive rock music tradition that AI has learned from
- Flexible rhyme schemes
- Rich vocabulary for emotional expression

This means English lyrics generally produce smoother AI vocals than other languages. However, this also means quality expectations are higher.

## Rule 1: Conversational But Crafted

Modern rock lyrics work best in conversational English, but with attention to imagery and rhythm. Avoid overly formal or overly casual extremes.

### Good (conversational with craft):
```
The clocks all stopped that quiet day
The moment that you closed the door
A glass still half-filled on the table
Where your lips had been before
```

### Too formal:
```
The temporal mechanisms ceased their function
Upon the moment of your egress
A receptacle remained partially full
```

### Too casual:
```
Yeah man, you left and I was sad
I just sat there, totally bummed
```

The middle ground feels authentic without being throwaway.

## Rule 2: Strong Opening Line

The opening line of your lyrics is critical. AI generators often emphasize the opening, and listeners decide whether to keep listening based on it.

Good opening lines:

- Set a scene: "The clocks all stopped that quiet day"
- Introduce conflict: "I tried to take a step this morning"
- Pose a question: "What's the point of waiting anymore?"
- Use vivid imagery: "Cigarette smoke filling up the empty room"

Avoid generic openings like:

- "I'm thinking about you tonight" (clichéd)
- "Once upon a time" (storybook)
- "Listen up" (lecturing)

## Rule 3: Rhyme Scheme Awareness

English rock typically uses these rhyme schemes:

- **ABAB** (alternating): Most common, classic feel
- **AABB** (couplets): Punchy, more direct
- **ABCB** (only second and fourth rhyme): Modern, less constrained
- **No rhyme**: Common in post-rock, atmospheric tracks

Don't force perfect rhymes. Near-rhymes and slant rhymes are acceptable and often more natural:

- "stone" and "alone" (perfect)
- "stone" and "home" (perfect)
- "stone" and "won" (slant, acceptable)
- "stone" and "moan" (perfect)

## Rule 4: Stress and Meter

English songs follow stress patterns more strictly than Turkish. Read lines out loud to check natural stress.

### Good stress pattern:
```
A WIN-dow and an EMP-ty CHAIR  (4 stresses)
The OLD road just out-SIDE  (3 stresses, but flows)
```

### Awkward stress:
```
The WINDOW and a CHAIR that is em-PTY  (forced final stress)
```

Iambic patterns (unstressed-stressed) often feel most natural in English rock.

## Rule 5: Concrete Over Abstract

This rule applies across languages, but is especially important in English. Specific images outperform abstract concepts.

### Concrete (works):
```
Letters fill the drawer beside me
Never opened, never sent
```

### Abstract (less effective):
```
Communication remains undelivered
The connection was never made
```

Concrete imagery gives the listener something to visualize and feel.

## Rule 6: Emotional Truth Over Cleverness

Don't sacrifice emotional impact for clever wordplay. The listener should feel something, not admire your vocabulary.

### Good (emotional):
```
I am a stranger in my own four walls
And all that's left is ash that falls
```

### Too clever:
```
Domiciled yet alienated, paradoxically
Combustion's residue all that perdures
```

Emotional truth always wins over cleverness in popular music.

## Rule 7: Chorus Hook Discipline

The chorus is what listeners remember. Apply these rules to chorus writing:

- Keep the hook to 4-7 syllables for maximum memorability
- Use repetition strategically (twice or three times within one chorus)
- The hook should work both as a complete thought and as a fragment
- Avoid complex grammar; simple sentences hit harder

### Example of disciplined chorus:
```
[Chorus]
You left, I stayed behind
A stranger in my own four walls
You left, I burned alive
And all that's left is ash that falls
```

Short phrases. Strong contrasts. Repeated hook ("You left").

## Rule 8: Verse-Chorus Contrast

English rock benefits from clear emotional contrast between verses and choruses.

- **Verses:** Detailed, narrative, image-rich, often quieter
- **Choruses:** Anthemic, declarative, simpler, often louder

The verses tell the story; the chorus expresses the emotional core. This contrast makes both stronger.

## Rule 9: Bridge as Revelation

In English rock, the bridge often introduces:

- A new perspective ("Maybe you're somewhere too...")
- A revelation ("I've been the problem all along")
- A question ("Will I ever move again?")
- An unexpected hope or despair

The bridge breaks the verse-chorus pattern and earns the final chorus.

## Rule 10: Avoid Common Tropes

Some lyrical tropes are so overused that they immediately feel generic. Avoid or transform these:

- "Looking up at the stars" (overused)
- "Tears falling like rain" (cliché simile)
- "Dancing in the moonlight" (worn out)
- "Heart on my sleeve" (idiom overuse)
- "Fire in my soul" (generic)
- "Through the storm" (generic)

When you find yourself reaching for one of these, pause and write something more specific to your song.

## Vocabulary Choices

Different rock subgenres favor different vocabulary registers:

### Grunge / Post-grunge:
- Direct, working-class, emotional
- Words like: "burn", "lost", "broken", "stay", "alone"
- Avoid: ornate or elevated vocabulary

### Hard Rock:
- Powerful, declarative, sometimes anthemic
- Words like: "fire", "fight", "stand", "rise", "thunder"
- Avoid: passive constructions

### Post-Rock / Atmospheric:
- Often instrumental or minimal vocals
- When vocals appear: poetic, fragmentary, evocative
- Words like: "quiet", "shadow", "echo", "drift", "fade"

### Punk:
- Confrontational, urgent, sometimes political
- Words like: "now", "tear", "break", "burn", "no"
- Avoid: nuance or hesitation

### Indie / Alternative:
- Conversational, ironic, sometimes literary
- Words like: "maybe", "suppose", "anyway", "still"
- Avoid: melodrama

## Sentence Structure for AI Vocals

AI vocals work best with these structural patterns:

### Good (clear and singable):
```
The room still holds your scent inside
My phone went silent, so did I
```

### Avoid (run-on or fragmented):
```
The room which still holds your scent inside continues to remind me
Of you, of you, of you, of you
```

Run-on sentences confuse AI vocal timing. Fragments break flow.

## Tense Consistency

Within a verse, maintain tense consistency unless deliberately shifting:

### Good (consistent past):
```
I tried to take a step this morning
My feet were rooted to the floor
I tried to make a call to someone
My fingers froze, I couldn't anymore
```

### Inconsistent (jumps tenses):
```
I tried to take a step this morning
My feet are rooted to the floor
I will try to make a call to someone
My fingers froze, I couldn't anymore
```

If you shift tense between sections (e.g., past in verses, present in chorus), make it intentional.

## Pronoun Discipline

Be clear about who "I", "you", "we", "they" refer to. Especially in songs about relationships, ambiguity can be powerful but should be intentional.

### Clear (intentional ambiguity is fine):
```
You left, I stayed behind
```
Clear: "you" is the lover, "I" is the speaker.

### Confusing:
```
She told them that we were all going to be wherever they used to be
```
Too many pronouns, no clarity.

## Final Quality Check

Before finalizing English lyrics:

1. Read out loud — does it flow with natural English stress?
2. Check rhyme — any forced or generic rhymes?
3. Check imagery — concrete and specific?
4. Check clichés — any overused tropes?
5. Check tense consistency — intentional shifts only?
6. Check vocabulary register — matches the subgenre?
7. Check chorus hook — memorable and singable?
8. Check bridge — adds something new to the song?

If all checks pass, the lyrics are ready for AI generation.
