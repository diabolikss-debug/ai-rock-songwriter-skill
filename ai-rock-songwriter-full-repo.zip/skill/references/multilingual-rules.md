# Multilingual Adaptation Rules

This document covers how to produce the same song in multiple languages without losing emotional impact, atmosphere, or musical fit. Adaptation is not translation; it's a craft of preserving meaning while adapting form.

## Core Principle: Adaptation, Not Translation

When producing the same song in two or more languages:

- **Preserve:** meaning, emotional weight, atmosphere, structural feel
- **Adapt:** rhyme scheme, line length, specific imagery (when needed), idioms, cultural references

A good adaptation should feel like an authentic song in the target language, not a translated version of the original.

## When to Use Multiple Languages

Common scenarios where multilingual versions add value:

- Building a bilingual or multilingual music channel
- Reaching different audience markets
- Cultural bridge content
- Showcasing artistic versatility
- Strategic SEO across language markets

## Workflow for Multilingual Production

### Step 1: Establish the Original

Always create the song in one primary language first. This is the "original" that captures:

- The core emotional truth
- The central metaphors
- The specific imagery
- The musical structure

The primary language should be the one closest to the writer's emotional reality.

### Step 2: Identify Translatable vs. Adaptable Elements

Go through the original lyrics and categorize:

**Translatable (preserve as-is):**
- Specific scenarios ("the empty chair", "the half-empty glass")
- Universal emotions (grief, longing, anger)
- Narrative beats ("you left", "I waited")

**Adaptable (need transformation):**
- Idioms ("kül oldu" → "burned to ash" works; some idioms don't transfer)
- Cultural references (specific cafes, places, historical references)
- Rhyme schemes (rarely survive translation)
- Wordplay or puns (almost never transfer)
- Metaphors tied to specific language sounds

### Step 3: Adapt the Title

Title adaptation has three approaches:

**Approach A: Direct equivalent**
- Turkish "Kül" → English "Ash"
- Turkish "Sabit" → English "Static"

This works when the word has a clear, strong equivalent.

**Approach B: Stronger English/target language word**
- Turkish "Yorgun" (tired) → English "Hollow" (more evocative in English)

This works when the direct translation feels weak in the target language.

**Approach C: New title that captures the feeling**
- Turkish "Bir Pencere" (A Window) → English "Watching Through Glass"

This works when no single word captures the same weight.

### Step 4: Rewrite Verse by Verse

Don't translate line by line. Take each verse as a unit and rewrite it in the target language with these priorities:

1. The verse should make complete emotional sense in the target language
2. The imagery should feel native to the target language
3. The rhyme scheme should work naturally
4. The line lengths should fit the musical phrasing
5. The vocabulary register should match the subgenre

### Step 5: Verify Singability

After rewriting, read the lyrics aloud as if singing them. Check:

- Do the lines fit the same musical phrases as the original?
- Are there awkward stress patterns?
- Does any line feel rushed or stretched?
- Does the chorus hook hit as hard?

If any of these fail, revise.

## Specific Language Pair Notes

### Turkish to English

**Common pitfalls:**
- Turkish suffix-based rhymes don't survive ("yıllarca" / "uzakta" / "burada" rhyme through grammar; English requires different rhyme strategy)
- Turkish has agglutination (long compound words) that need to expand into multiple English words
- Some Turkish concepts (like "hasret") need multi-word English approximations ("longing", "yearning")

**Adaptation strategy:**
- Accept that English version will have different rhyme patterns
- Use English's flexibility with line length
- Allow English to be slightly more direct (Turkish allows more poetic ambiguity)

### English to Turkish

**Common pitfalls:**
- English contractions ("I'm", "don't", "you're") have no Turkish equivalent
- English's strong emphasis on subject pronouns; Turkish often drops them
- English idioms (like "heart on my sleeve") rarely translate

**Adaptation strategy:**
- Expand contractions naturally
- Drop pronouns when grammatically natural in Turkish
- Replace English idioms with Turkish equivalents or omit

### Turkish to/from Other Languages

For Turkish paired with Spanish, French, German, Italian, or Portuguese:

- Each language has its own poetic conventions
- Romance languages (Spanish, French, Italian, Portuguese) tend to have similar rhyme flexibility
- German has its own compound word strategies
- Always research the target language's contemporary rock conventions

## Adaptation Examples

### Example 1: Direct Translation (Don't Do This)

Original Turkish:
```
Bir bardak hala yarım masada
Senin dudağının izinde
```

Bad direct translation:
```
A glass still half on the table
On the trace of your lip
```

This is grammatically odd in English and the imagery feels translated.

### Example 2: Proper Adaptation

Original Turkish:
```
Bir bardak hala yarım masada
Senin dudağının izinde
```

Good adaptation:
```
A glass still half-filled on the table
Where your lips had been before
```

Same meaning, same imagery, but flows naturally in English with proper grammar and natural phrasing.

### Example 3: Chorus Adaptation

Original Turkish chorus:
```
Sen gittin, ben kaldım
Bu evin içinde bir yabancı gibi
Sen gittin, ben yandım
Geriye kalan sadece kül
```

Good English adaptation:
```
You left, I stayed behind
A stranger in my own four walls
You left, I burned alive
And all that's left is ash that falls
```

The hook ("Sen gittin" → "You left") is preserved. The imagery ("yabancı" → "stranger", "yandım" → "burned alive", "kül" → "ash") translates naturally. New rhyme scheme works in English ("walls" / "falls"). The emotional weight is identical.

## Cultural Sensitivity in Adaptation

Some imagery may need cultural adjustment:

- **Religious imagery:** A reference that's neutral in one culture may be loaded in another. Adjust if needed.
- **Geographic references:** A specific place may need to become generic or replaced with a target-culture equivalent.
- **Historical events:** Avoid culture-specific historical references unless central to the song.
- **Food, drink, clothing:** These are often culture-specific; consider whether to keep specific or generalize.

## Vocal and Pronunciation Considerations

When the same Persona sings both versions, consider:

- The Persona's accent should match the language being sung
- Some Personas may handle one language better than another
- Test both versions and adjust the Persona if needed
- For commercial channels, consistency matters more than perfection

## Style Prompt Adaptation

The Suno style prompt should match the target language version:

### For Turkish version:
```
[...all style components...] Turkish language vocals
```

### For English version:
```
[...all style components...] English language vocals
```

All other style components (genre, era, tempo, instruments, dynamics) should remain identical to maintain musical consistency between versions.

## Title Format for Multilingual Releases

Standard format suggestions:

### Same channel, separate videos:
- Video 1: "Kül - The Riff Keeper | Türkçe Grunge Original"
- Video 2: "Ash - The Riff Keeper | Original Grunge Ballad"

### Combined video (less common):
- "Kül / Ash - The Riff Keeper | Bilingual Single"

The separate-video approach generally performs better for algorithmic discovery.

## Description Cross-Linking

In each video's description, link to the other language version:

### In Turkish video description:
```
ENGLISH VERSION
Bu şarkının İngilizce versiyonu "Ash" başlığıyla yayında.
[Link to English version]
```

### In English video description:
```
TURKISH VERSION
The original Turkish version is available under the title "Kül".
[Link to Turkish version]
```

This cross-linking improves both videos' performance and audience retention.

## Final Quality Check for Adaptations

Before finalizing the multilingual version:

1. **Emotional check:** Does the target language version feel as emotionally impactful?
2. **Naturalness check:** Does it sound like a native song in the target language?
3. **Imagery check:** Are the metaphors and images preserved or adapted appropriately?
4. **Singability check:** Does it fit the same musical phrasing?
5. **Hook check:** Is the chorus hook as strong?
6. **Cultural check:** Are there any cultural insensitivities or awkward references?

If all checks pass, the adaptation is ready.

## Working with Reference Songs Across Languages

If a user provides a reference song in a different language than their target:

1. Ignore the lyrics of the reference (only use musical atmosphere)
2. Build entirely original lyrics in the target language
3. Use the reference only for tempo, mood, and structural feel
4. Apply all copyright safety rules from `references/copyright-safety.md`

The reference language doesn't matter; the rules are language-independent.
