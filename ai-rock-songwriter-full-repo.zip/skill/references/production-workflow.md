# Production Workflow

This document outlines the end-to-end production workflow for AI-generated rock songs, from initial concept to final upload-ready files.

## Workflow Overview

The complete workflow has six phases:

1. **Concept and Brief**
2. **Lyrics and Style Prompt Creation**
3. **AI Generation**
4. **Selection and Refinement**
5. **Post-Production**
6. **Distribution Preparation**

This skill primarily handles phases 1-2 and 4. Users handle phases 3, 5, and 6 with the skill's guidance.

## Phase 1: Concept and Brief

### Inputs Needed

Before writing anything, gather:

- **Theme:** What is the song about?
- **Target emotion:** What should the listener feel?
- **Genre/subgenre:** What rock style?
- **Reference atmosphere (optional):** Any specific musical mood as inspiration?
- **Language(s):** Single language or multiple versions?
- **Duration target:** Default 4 minutes or different?
- **Channel context:** Is this for an existing channel with established identity?

### Brief Confirmation

Before proceeding, confirm the brief with the user. Sometimes themes or references need clarification. A 30-second confirmation prevents rewrites later.

### Theme Refinement

If the user's theme is too broad, help refine it:

- "Sad" → "Sad about a specific lost relationship"
- "Angry" → "Angry at oneself for making a wrong choice"
- "Hopeful" → "Cautiously hopeful about starting over"

Specific themes produce better songs than abstract ones.

## Phase 2: Lyrics and Style Prompt Creation

### Order of Creation

1. Title options first (quick, helps establish identity)
2. Lyrics second (the core creative work)
3. Style prompt third (informed by the lyrics)
4. Production tips last (specific to the finished package)

### Quality Gates

Before delivering to the user, verify:

- All copyright safety rules followed
- Language-specific rules applied (Turkish, English, etc.)
- Structure tags correctly used
- Style prompt has all 9 components
- Multilingual versions are adapted, not translated
- Production tips address likely challenges

## Phase 3: AI Generation (User Phase)

The user takes the deliverables to Suno or Udio. Recommendations to provide:

### Suno Settings

- **Mode:** Custom Mode (not Quick)
- **Lyrics:** Paste full lyrics with structure tags
- **Style of Music:** Paste the style prompt
- **Title:** The chosen title (just the song name, no channel branding)
- **Persona:** Use established Persona for channel consistency, or generate new for first song
- **Make Instrumental:** Off (unless requested)
- **Model:** Latest version available

### Generation Strategy

- Generate **4-6 variations** per song
- Listen to each variation in full
- Note which variations have the best:
  - Vocal performance
  - Mix quality
  - Emotional impact
  - Adherence to structure

### Common Issues and Solutions

**Issue: Song is too long**
- Add "total duration approximately 240 seconds, focused song no extended jams" to style prompt
- Add inline timing to Bridge and Outro
- Remove second Pre-Chorus

**Issue: Song is too short**
- Allow extended outro: "extended atmospheric outro, gradual emotional resolution"
- Add second Pre-Chorus
- Lengthen Verse 2

**Issue: Vocal is wrong gender**
- Reinforce in style prompt: "Male vocals only" or "Female vocals only"
- Try a different Persona

**Issue: Vocal is too polished**
- Add "raw unpolished vocal delivery, vocal cracks acceptable, deliberately imperfect"

**Issue: Vocal is too raw/aggressive**
- Add "controlled emotional vocal delivery, melodic phrasing, restrained power"

**Issue: Wrong tempo feel**
- Adjust BPM by 5-10
- Change tempo descriptor: "slow burn" vs "driving" vs "anthemic"

**Issue: Genre feels off**
- Strengthen subgenre descriptor with more specific era/scene reference
- Add more instrument-specific details

## Phase 4: Selection and Refinement

### Selection Criteria

When choosing among generations, prioritize:

1. **Vocal quality:** Strong emotional delivery, correct character, in-tune
2. **Mix balance:** Vocals audible, instruments balanced, no muddy sections
3. **Structural integrity:** Sections flow naturally, dynamics work
4. **Emotional impact:** Does it move you?
5. **Production fit:** Does it match the desired era and aesthetic?

A vocally great track with mediocre mix beats a perfect mix with weak vocals.

### Refinement Options

If the best generation has minor issues:

- **Suno Extend:** Lengthen specific sections
- **Suno Inpaint:** Replace short sections within the song
- **Suno Cover:** Generate variations of the chosen track
- **Suno Stems:** Separate vocals/instruments for external mixing (Pro feature)

### When to Regenerate

Regenerate (rather than refine) if:

- Vocal character is fundamentally wrong
- Genre feel is off in multiple sections
- Lyrics aren't being sung correctly (especially in non-English)
- The mix quality is too low for distribution

Don't regenerate dozens of times hoping for perfection. After 8-10 generations with adjustments, the diminishing returns kick in.

## Phase 5: Post-Production (User Phase)

### Audio Processing

Recommended steps:

1. **Download highest quality version** from Suno (WAV preferred over MP3)
2. **Loudness normalize** to LUFS -14 (YouTube standard)
3. **Light EQ corrections** if needed (slight high-shelf boost for clarity)
4. **Subtle compression** if dynamics are too wide
5. **Master to platform standards**

Tools commonly used:

- **Audacity** (free): Basic editing and normalization
- **Reaper** ($60): Full DAW for serious work
- **iZotope Ozone** ($129+): One-click mastering
- **DaVinci Resolve** (free): Audio + video together

### Video Production (For YouTube)

Standard formats:

- **Single static image with slow zoom:** Easiest, professional
- **3-5 image rotation with crossfades:** More dynamic
- **AI-generated video clips:** Highest production value, most work
- **Lyric video:** Text appearing in sync with vocals

Tools:

- **Canva:** Easy static image to video
- **DaVinci Resolve:** Free professional video editing
- **CapCut:** Mobile/desktop with AI features
- **Runway, Kling, or Hailuo:** AI video generation

## Phase 6: Distribution Preparation

### Required Assets per Release

For YouTube:

- Final audio file (MP3 or WAV)
- Video file (MP4, 1080p minimum)
- Thumbnail (1280x720 px, under 2MB)
- Title (under 100 characters)
- Description (with chapters, AI disclosure, links)
- Tags (15-20 relevant keywords)
- Category: Music
- AI content disclosure: ON

### Cross-Platform Preparation

For multilingual releases, prepare separately:

- Different titles in respective languages
- Different descriptions
- Different tags
- Cross-link in descriptions

### Pre-Upload Checklist

- [ ] Audio loudness verified (LUFS -14)
- [ ] Video resolution at least 1080p
- [ ] Thumbnail in correct dimensions
- [ ] Title under character limit
- [ ] Description includes AI disclosure
- [ ] Description includes chapters/timestamps
- [ ] Tags don't include artist names
- [ ] Cross-links to other language version (if applicable)
- [ ] License documentation archived

## Channel Building Considerations

### Consistency

For users building a channel, emphasize consistency:

- Same Persona for vocal identity
- Consistent visual aesthetics
- Predictable release schedule
- Recognizable opening/closing elements
- Coherent thematic universe

### Catalog Strategy

Recommend a release strategy:

- **First 5 songs:** Establish identity and prove concept
- **Songs 6-15:** Expand thematic range while maintaining vocal consistency
- **Songs 16+:** Begin curating playlists, EPs, or thematic collections
- **Year 1+:** Consider album-style releases, special editions

### Performance Tracking

Recommend tracking these metrics per release:

- View count (vanity metric)
- Watch time (algorithm metric)
- Audience retention curve (where do listeners drop off?)
- Click-through rate on thumbnail
- Subscriber conversion
- Comment engagement

These metrics inform future production decisions.

## Common Pitfalls in AI Music Production

### Pitfall 1: Over-Producing the First Song

Don't pour endless hours into one song. Get something good out, learn from results, apply learnings to next song.

### Pitfall 2: Inconsistent Identity

Switching vocal styles, genres, and aesthetics every release confuses audiences. Maintain identity for at least 5-10 releases before evolving.

### Pitfall 3: Ignoring Audio Quality

AI-generated audio sometimes has compression artifacts. Always check on multiple speakers/headphones before publishing.

### Pitfall 4: Skipping AI Disclosure

In 2026, AI disclosure is policy on most platforms. Skipping it risks demonetization or removal.

### Pitfall 5: Copying Trends

Don't chase what's trending. Build something authentic to your vision. Trend-chasing produces forgettable content.

## Success Metrics

A well-produced AI rock song should:

1. Sound like a genuine rock song, not an AI gimmick
2. Have emotional impact that transcends the production method
3. Fit naturally into a curated channel identity
4. Pass copyright safety checks
5. Generate audience engagement beyond just views
6. Be something the producer is proud to share

If a song meets these criteria, the workflow has succeeded.
