# Song Structure Guide

This document provides detailed structure guidance for AI-generated rock songs. The 4-minute commercial format is the default, but variations are covered for different needs.

## The Standard 4-Minute Structure

Most AI-generated rock songs target a 4-minute duration (3:50-4:10). This format works well because:

- It's the standard radio and streaming length
- Fits algorithmic preferences on most platforms
- Allows full emotional development without dragging
- Works for both casual listening and focused engagement

## Section-by-Section Breakdown

### Intro (15-20 seconds)

Purpose: Set the atmosphere, draw the listener in, establish the song's musical identity.

Suno tag: `[Intro]`

Content suggestions:
- Instrumental only (no vocals)
- Clean arpeggiated guitar with reverb
- Subtle bass entrance
- Atmospheric texture (ambient pads, soft strings)
- Solo guitar motif that hints at the chorus melody

Inline guidance for Suno:
```
[Intro] (instrumental, 15 seconds, slow melancholic guitar arpeggio with subtle reverb)
```

### Verse 1 (30-40 seconds)

Purpose: Establish the narrative, introduce the speaker's perspective, create vivid imagery.

Suno tag: `[Verse 1]`

Content guidelines:
- 6-8 lines typically
- First-person narrative
- Concrete imagery
- Set the scene
- Build toward the emotional core

Example structure:
```
[Verse 1]
Line 1: Set the scene
Line 2: Add specific detail
Line 3: Continue the imagery
Line 4: Introduce the emotional weight
Line 5-8: Develop the situation
```

### Pre-Chorus (15-20 seconds)

Purpose: Build tension and elevation toward the chorus. The musical energy increases here.

Suno tag: `[Pre-Chorus]`

Content guidelines:
- 4 lines typically
- More abstract or emotional than the verse
- Often poses a question or tension
- Lifts musically toward the chorus
- Repeats melodic and lyrical structure

The pre-chorus is the bridge between the storytelling verse and the anthemic chorus. It can be omitted in some songs but generally improves emotional impact.

### Chorus (25-35 seconds)

Purpose: Deliver the song's central emotional statement; provide the memorable hook.

Suno tag: `[Chorus]`

Content guidelines:
- 4-6 lines, often 4
- Most repeatable section
- Strongest emotional declaration
- The "title hook" often appears here
- Should work as a complete thought independently

The chorus is what listeners remember. It carries the song's identity.

### Verse 2 (30-40 seconds)

Purpose: Advance the narrative, deepen the emotional context, add new perspective.

Suno tag: `[Verse 2]`

Content guidelines:
- Same structural weight as Verse 1
- New imagery and information
- Deepens or complicates the emotional landscape
- Should not repeat Verse 1's imagery

The second verse should feel like the next chapter of the story, not a restatement.

### Pre-Chorus Repeat (Optional, 15-20 seconds)

Some songs repeat the pre-chorus before the second chorus. Others skip it for momentum. Decision factors:

- **Repeat the pre-chorus** if the song needs the lift again
- **Skip the pre-chorus** if the song needs to maintain forward momentum
- For 4-minute songs, often skipping keeps the duration on target

### Chorus Repeat (25-35 seconds)

Purpose: Reinforce the central emotional message; provide listener satisfaction through familiarity.

Same content as the first chorus, often with slight melodic variations. Some songs add an extra line or change one word for impact.

### Bridge (20-25 seconds)

Purpose: Provide contrast, introduce a new perspective, prepare for the climactic finale.

Suno tag: `[Bridge]`

Content guidelines:
- Quieter or more intimate than verses and choruses
- 4-6 lines
- New emotional direction or revelation
- Often more abstract or philosophical
- Sets up the final chorus's impact

The bridge is the most flexible section. It can:
- Shift to a new perspective
- Introduce a hopeful element in an otherwise dark song
- Reveal a deeper truth
- Provide the song's emotional turning point

Inline guidance for Suno:
```
[Bridge] (quieter, more intimate, 20 seconds, melodic guitar moment)
```

### Final Chorus (25-35 seconds)

Purpose: Climactic resolution; deliver the song's full emotional weight.

Suno tag: `[Final Chorus - Climactic]`

Content guidelines:
- Same as the regular chorus
- Often more vocally intense
- May have additional instrumentation
- Can include slight lyrical variation for impact

Adding "Climactic" to the tag tells Suno to deliver this section with maximum energy.

### Outro (25-35 seconds)

Purpose: Provide emotional resolution; let the song breathe and fade.

Suno tag: `[Outro]`

Content guidelines:
- Often instrumental or with sparse vocal repetitions
- Echoes of the chorus hook may appear
- Gradual fade or natural ending
- Atmospheric closing texture

Inline guidance for Suno:
```
[Outro] (extended instrumental, 25 seconds, single guitar with reverb fading)
"Word..."
(whispered)
"Phrase..."
```

## Structure Variations

### The Slow Burn Ballad (5-6 minutes)

For atmospheric, build-and-release songs:

```
[Intro] - 25-30 seconds
[Verse 1] - 45 seconds
[Pre-Chorus] - 20 seconds
[Chorus] - 35 seconds
[Verse 2] - 45 seconds
[Pre-Chorus] - 20 seconds
[Chorus] - 35 seconds
[Bridge - Quiet] - 30 seconds
[Bridge - Build] - 30 seconds
[Final Chorus - Climactic] - 45 seconds
[Outro - Extended] - 60 seconds
```

This structure suits doom, post-rock, and atmospheric ballads where emotional development matters more than runtime.

### The Punk Burst (2-2.5 minutes)

For high-energy, urgent songs:

```
[Intro] - 5 seconds (count-in or short riff)
[Verse 1] - 25 seconds
[Chorus] - 20 seconds
[Verse 2] - 25 seconds
[Chorus] - 20 seconds
[Bridge - Brief] - 15 seconds
[Final Chorus] - 25 seconds
[Outro] - 5 seconds
```

Punk doesn't need a pre-chorus or extended sections. Keep it fast and direct.

### The Post-Rock Crescendo (6-9 minutes)

For instrumental or near-instrumental atmospheric tracks:

```
[Intro - Atmospheric] - 60 seconds
[Section 1 - Quiet] - 90 seconds
[Section 2 - Build] - 90 seconds
[Climax] - 90 seconds
[Resolution] - 60 seconds
[Outro - Fade] - 60 seconds
```

These tracks don't follow verse-chorus structure. They're sections that flow into one another.

### The Stoner Jam (5-7 minutes)

For groove-based stoner and doom tracks:

```
[Intro - Riff] - 30 seconds
[Verse 1] - 45 seconds
[Chorus] - 30 seconds
[Verse 2] - 45 seconds
[Chorus] - 30 seconds
[Instrumental Jam] - 90 seconds
[Final Chorus] - 30 seconds
[Outro - Heavy] - 45 seconds
```

The instrumental jam is essential to the genre. Don't cut it short.

## Duration Control with Suno

Suno often produces songs that are too long or too short. Apply these techniques:

### To enforce shorter duration:

In the style prompt, add:
```
four-minute song structure, focused song no extended jams, total duration approximately 240 seconds
```

In specific sections, add inline timing:
```
[Bridge] (brief, 15 seconds maximum)
[Outro] (very short fade, 20 seconds maximum)
```

### To allow longer duration:

In the style prompt, add:
```
six-minute song structure, extended atmospheric outro acceptable, immersive instrumental sections allowed
```

In specific sections:
```
[Bridge] (extended, 45 seconds, melodic build)
[Outro] (long instrumental fade, 90 seconds with vocal ad-libs)
```

## Section Emphasis Tags

Suno responds well to descriptive tags within section markers. These improve output quality:

```
[Verse 1] (intimate, vocal-forward, sparse instrumentation)
[Pre-Chorus] (building tension, drums entering)
[Chorus] (full band, anthemic energy)
[Bridge] (quieter, more intimate, sparse arrangement)
[Final Chorus - Climactic] (full intensity, additional layers)
[Outro] (gradual fade, single guitar, reverb-heavy)
```

These descriptors help Suno deliver the dynamic structure you envision.

## Line Count Guidelines

For each section, target line counts that fit musical timing:

| Section | Lines (4-min song) | Lines (6-min song) |
|---------|-------------------|-------------------|
| Verse 1 | 6-8 | 8-12 |
| Pre-Chorus | 4 | 4-6 |
| Chorus | 4-6 | 4-8 |
| Verse 2 | 6-8 | 8-12 |
| Bridge | 4-6 | 6-10 |

These are flexible. The musical phrasing matters more than exact line counts.

## When to Break the Rules

Standard structure works for most songs, but break rules when:

- The song's emotional truth demands a different shape
- You want to subvert listener expectations
- The genre traditionally uses different structures (jazz fusion, prog rock, etc.)
- The lyrical content can't be contained in standard sections

Examples of effective rule-breaking:

- **Starting with the chorus:** For attention-grabbing impact
- **No bridge:** For songs with simpler emotional arcs
- **Two bridges:** For songs with complex emotional development
- **Repeated outro phrases:** For mantric, hypnotic effects
- **Asymmetric verses:** When Verse 1 needs more space than Verse 2 (or vice versa)

The structure should serve the song, not constrain it.

## Final Structure Check

Before delivering lyrics, verify:

1. **Total duration estimate:** Does the line count match the target duration?
2. **Section balance:** Do verses, chorus, and bridge feel proportionate?
3. **Tag accuracy:** Are Suno structure tags correctly placed?
4. **Inline guidance:** Have you added section-specific descriptors?
5. **Emotional arc:** Does the structure deliver an emotional journey, not just sections?

If all checks pass, the structure is ready for AI generation.
