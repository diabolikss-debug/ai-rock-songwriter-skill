# Suno Style Prompt Templates

This document provides ready-to-use style prompts for major rock subgenres. All templates are copyright-safe (no artist names) and tested for Suno AI compatibility. Adjust language directive based on your target language.

## How to Use These Templates

Each template follows the 9-component structure required for high-quality Suno output. To customize:

1. Pick the template matching your target subgenre
2. Adjust tempo BPM if needed
3. Replace `[language]` with "Turkish language vocals", "English language vocals", or another language
4. Adjust theme/mood at the end based on your song's content
5. Paste into Suno's "Style of Music" field in Custom Mode

## Template Structure

Every template follows this pattern:

```
[Genre/subgenre], [era/atmosphere], [mood], [intro description], 
[tempo bpm], [vocal description], [instrument set], 
[dynamic structure], [duration instruction], [language] vocals, 
[theme/mood detail]
```

## Classic Rock (1970s style)

```
Classic rock, vintage 1970s warmth, analog tape texture, gritty mid-range guitars, 
Hammond organ in the background, driving bass groove, slightly loose drums with 
natural cymbal decay, bluesy phrasing without vocal acrobatics, mid-tempo around 
108 bpm, baritone male vocals with raw emotional weight, 
crescendo arrangement that builds across four minutes, four-minute song structure 
no extended jams, [language] vocals, themes of [your theme], nostalgic and powerful mood
```

## Hard Rock (Late 1970s to 1980s)

```
Hard rock, late 1970s power chord aesthetic, double-tracked rhythm guitars, 
prominent bass, punchy snare drum, clean unprocessed vocals with grit, 
no synthesizers, no modern compression, mid-tempo 110 bpm, anthemic chorus 
structure, four-minute song structure focused song, [language] vocals, 
themes of [your theme], driving and confident mood
```

## Doom Metal

```
Doom metal, slow tempo around 60 bpm, downtuned guitars, thick fuzz tone, 
repetitive crushing riffs, sparse drumming with heavy cymbal work, 
monolithic bass presence, occasional ambient breakdowns, smoky and ritualistic 
atmosphere, no fast sections, instrumental focus with minimal vocals, 
baritone male vocals with deep resonance, four-minute structure with extended 
heavy outro, [language] vocals, themes of [your theme], heavy and atmospheric mood
```

## Stoner Rock

```
Stoner rock, fuzzed-out guitars with desert tone, mid-tempo groove around 
90 bpm, swinging rhythm section, vintage 1970s production, occasional wah-wah 
leads, warm bass, hypnotic riff repetition, sun-baked psychedelic atmosphere, 
baritone male vocals with raw delivery, instrumental jam structure but focused 
to four minutes, [language] vocals, themes of [your theme], hypnotic and warm mood
```

## Post-Rock (Instrumental)

```
Instrumental post-rock, slow cinematic build, clean delayed guitars, ambient pads, 
gradual crescendo, post-rock dynamics with quiet verses and explosive climax, 
no vocals or minimal whispered vocals, glockenspiel and piano accents, 
emotional and contemplative mood, four-minute structure with three distinct 
sections, [language] vocals if any, themes of [your theme], emotional and cathartic mood
```

## Punk Rock

```
Late 1970s punk rock, raw garage production, three-chord progressions, 
sloppy energetic drums, distorted but thin guitars, shouted vocals with attitude, 
fast tempo around 160 bpm, no overdubs, live recording feel, urgent and 
confrontational mood, focused two-and-a-half minute structure short song, 
[language] vocals, themes of [your theme], urgent and rebellious mood
```

## Grunge (Pacific Northwest, early 1990s)

```
Early 1990s grunge, loud-quiet-loud dynamic structure, drop-D tuned guitars, 
melodic but anguished vocals, heavy bass distortion, alternate clean verses 
with crushing choruses, lo-fi production, Pacific Northwest atmosphere, 
melancholic but powerful mood, mid-tempo around 90 bpm, baritone male vocals 
with vocal cracks and emotional strain, four-minute structure with bridge, 
[language] vocals, themes of [your theme], melancholic and powerful mood
```

## Post-Grunge Ballad (early 2000s)

```
Atmospheric mid-tempo rock ballad, post-grunge sound from early 2000s, 
melancholic and introspective mood, clean arpeggiated guitar intro with 
subtle reverb and chorus effect, slow burn dynamic with gradual emotional 
build, mid-tempo around 88 bpm, baritone male vocals with rich resonance 
and emotional depth, vocals soulful and slightly haunting with smooth melodic 
phrasing, prominent bass guitar with melodic lines, drums steady and 
contemplative in verses with controlled crescendo in choruses, melodic 
electric guitar lead in bridge section with hauntingly beautiful tone, 
classic rock instrumentation with atmospheric reverb, four-minute song 
structure with extended emotional outro, [language] vocals, 
themes of [your theme], contemplative and emotionally weighted mood
```

## Alternative Indie Rock (mid-1990s)

```
Indie alternative rock, jangly clean guitars with chorus effect, melodic bass 
lines, restrained drumming, introspective vocals with reverb, mid-tempo, 
mid-1990s college rock production, emotional and slightly bittersweet, 
four-minute song structure with bridge, mid-tempo around 100 bpm, 
clean but emotional vocals, [language] vocals, themes of [your theme], 
introspective and bittersweet mood
```

## Garage Rock

```
Mid-1960s garage rock revival, fuzz guitars, simple two-chord vamps, 
primitive drumming, snotty vocals through tape echo, mono recording aesthetic, 
organic room sound, energetic and rebellious mood, three-minute song structure, 
fast tempo around 140 bpm, [language] vocals, themes of [your theme], 
raw and rebellious mood
```

## Shoegaze

```
Shoegaze, late 1980s to early 1990s British dream-rock aesthetic, layered 
walls of distorted guitars, reverb-drenched atmosphere, soft melodic vocals 
buried in the mix, prominent bass line, steady mid-tempo drums, dreamy and 
introspective mood, mid-tempo around 110 bpm, ethereal vocals with reverb, 
four-minute structure with hypnotic outro, [language] vocals, 
themes of [your theme], dreamy and immersive mood
```

## Sludge Rock

```
Sludge rock, heavy downtuned guitars with thick distortion, slow to mid-tempo 
around 70 bpm, growling but melodic vocals, heavy plodding drums, swampy 
southern atmosphere, lo-fi production with raw analog warmth, oppressive 
and powerful mood, four-minute structure with crushing crescendo, 
[language] vocals, themes of [your theme], heavy and oppressive mood
```

## Vocal Direction Add-Ons

If the default vocal in a template isn't quite right, append one of these to the end of any template:

### For more raw vocals:
```
gritty rough male vocals with vocal cracks and emotional strain, 
not polished, deliberately raw and imperfect delivery
```

### For more melodic vocals:
```
smooth melodic male vocals with rich tone, controlled but emotionally 
expressive, classic rock vocal craft with melodic phrasing
```

### For deeper baritone:
```
deep baritone vocals with rich lower register, powerful but restrained, 
soulful rock delivery with emotional weight
```

### For higher tenor:
```
melodic tenor male vocals with emotional reach, occasional falsetto 
in chorus moments, expressive but not theatrical
```

### For female vocals:
```
female alto vocals with warm tone, emotional delivery, mid-range power, 
not pop-styled, rock-grounded vocal craft
```

## Duration Control Add-Ons

If Suno keeps producing songs that are too long or too short:

### To force shorter duration:
```
total duration approximately 240 seconds, no extended instrumental sections, 
focused song structure, brief outro
```

### To allow longer atmospheric sections:
```
six-minute song structure, extended atmospheric outro acceptable, 
gradual emotional resolution, immersive instrumental sections allowed
```

## Tempo Reference Guide

| BPM | Feel | Subgenres |
|-----|------|-----------|
| 60-70 | Very slow, doom | Doom metal, sludge, slow ballad |
| 70-85 | Slow ballad | Post-grunge ballad, atmospheric rock |
| 85-100 | Mid-tempo | Grunge, alternative, classic rock |
| 100-115 | Driving | Hard rock, post-rock builds |
| 115-130 | Energetic | Indie rock, alternative |
| 130-150 | Fast | Punk, garage, hardcore |
| 150-180 | Very fast | Punk, hardcore, fast metal |

## Final Tips

- Always generate 4-6 variations in Suno, then select the best
- If first results are off, adjust ONE component at a time (e.g., just the tempo, just the era)
- Save successful prompts as templates for future songs
- Track which Personas work best for your channel's vocal identity
