# Turkish Lyrics Rules

This document outlines the specific rules for writing Turkish-language song lyrics that work well with AI music generators (especially Suno). These rules are based on observed Suno behavior with Turkish language and natural Turkish songwriting craft.

## Why Turkish Needs Special Rules

Suno was primarily trained on English-language content. While it supports Turkish, certain Turkish-specific features cause pronunciation issues, awkward phrasing, or lost meaning. Following these rules ensures your Turkish lyrics are properly sung, naturally phrased, and emotionally resonant.

## Rule 1: No Inverted (Devrik) Sentence Structure

Turkish allows poetic sentence inversion (devrik cümle), but Suno struggles with these structures. Always use standard subject-object-verb order.

### Good (standard structure):
```
Sen kapıyı kapattığında saatler durdu
Bu evin içinde bir yabancı gibi yaşıyorum
```

### Bad (devrik):
```
Saatler durdu, sen kapattığında kapıyı
Yaşıyorum bu evin içinde bir yabancı gibi
```

The standard form sounds more natural when sung and avoids Suno's pronunciation issues with inverted phrases.

## Rule 2: Simplify Turkish Characters

Suno mispronounces certain Turkish characters with circumflexes. Simplify these in your lyrics:

| Turkish Character | Replacement | Example |
|------------------|-------------|---------|
| â | a | "hâlâ" → "hala" |
| î | i | "kâtip" → "katip" |
| û | u | "sükûn" → "sukun" |

The standard Turkish characters (ç, ğ, ı, ö, ş, ü) are pronounced correctly by Suno and should be kept.

## Rule 3: Keep Lines Short

Suno performs better with shorter Turkish lines. Aim for:

- **Verse lines:** 5-8 words per line
- **Chorus lines:** 4-7 words per line
- **Pre-chorus lines:** 4-6 words per line
- **Bridge lines:** 5-8 words per line

### Good (short lines):
```
Bir bardak hala yarım masada
Senin dudağının izinde
```

### Bad (too long):
```
Masanın üzerinde duran o bardak hala yarım kalmış halde duruyor şimdi
```

Long lines force Suno to compress syllables, which sounds unnatural.

## Rule 4: Modern Conversational Language

Use everyday Turkish, not archaic or overly literary language. Modern Turkish songs (especially in rock) sound more authentic with conversational vocabulary.

### Good (modern):
```
Telefonum sustu, kalbim sustu
Hatıralar konuşur hala
```

### Avoid (archaic):
```
Mahzun bakışlarımla seyrederim güzergahını
Hicran ile yanmaktadır kalbim eylediğin
```

Archaic vocabulary feels forced in modern rock contexts and can make AI-generated vocals sound stilted.

## Rule 5: Meaning Over Rhyme

Don't force rhymes at the expense of meaning. Turkish has natural rhyme patterns through suffixes, but contrived rhyming sounds artificial.

### Good (natural):
```
Bekledim ben yıllarca
Sözünü tuttuğun günü
Şimdi sadece bir gölgeyim
Bu odanın bir köşesi
```

The flow and meaning come first; rhyming happens naturally through Turkish grammar.

### Bad (forced rhyme):
```
Bekledim ben yıllarca
Konuşmadın hiç asla
Şimdi yoksun yanımda
Kalbim doldu hep dertle
```

Forced rhymes feel mechanical and reduce emotional impact.

## Rule 6: Turkish Stress and Rhythm

Turkish has its own natural stress patterns. Most Turkish words are stressed on the final syllable, but verbs and certain word types have different patterns. When writing for music:

- Don't force English-style stress patterns onto Turkish words
- Let natural Turkish rhythm guide phrase construction
- Read your lyrics out loud to check the rhythm before finalizing

## Rule 7: Avoid Direct Romantic Clichés

Turkish has many overused romantic phrases that feel cliché in modern rock. Avoid these unless used ironically:

- "Seni seviyorum" (I love you) - too direct, lacks craft
- "Kalbim seninle" (My heart is with you) - cliché
- "Sensiz olmaz" (I can't without you) - overused
- "Aşkım benim" (My love) - cliché in modern rock context

### Better alternatives that suggest love without clichés:
```
Senin yokluğun bu odanın yarısı
Hala konuşur hatıralar burada
Geride kalan sadece sen değildin
```

These phrases convey emotion through specific imagery rather than declaration.

## Rule 8: Use Concrete Imagery

Turkish rock lyrics work best with concrete, sensory imagery rather than abstract concepts.

### Good (concrete):
```
Yağmur yağıyor pencerede
Senin sevdiğin şarkı çalıyor
Radyoyu kapatamıyorum
```

### Less effective (abstract):
```
Hayatımın anlamı kayboldu
Boşlukta dolaşıyorum şimdi
Varlığımın özü değişti
```

Concrete details give the listener something specific to hold onto and feel.

## Rule 9: Chorus Repetition Patterns

For Turkish choruses that work well with AI generation:

- Repeat the central hook 2-3 times within one chorus
- Use shorter, more rhythmic phrases in the chorus
- Make the chorus easier to remember than the verses
- The final chorus can have variations or additions for climactic effect

### Example structure:
```
[Chorus]
Sen gittin, ben kaldım
Bu evin içinde bir yabancı gibi
Sen gittin, ben yandım
Geriye kalan sadece kül
```

The repetition of "Sen gittin" creates a memorable hook.

## Rule 10: Bridge as Emotional Pivot

The bridge section in Turkish songs works best as an emotional pivot. This is where you can:

- Shift perspective (e.g., from anger to acceptance)
- Add a new piece of imagery that recontextualizes the rest
- Get more intimate and quiet
- Hint at the song's resolution or final emotional position

### Example bridge:
```
[Bridge]
Belki bir gün karşılaşırız
Sen gülümsersin uzaktan
Ben başımı çeviririm
Çünkü görmek hatırlamaktan ağır
```

This bridge shifts from "you're gone" to "we might meet again" — adding complexity and depth.

## Common Turkish Songwriting Pitfalls

### Pitfall 1: Translation Thinking
Don't think in English and translate to Turkish. Think in Turkish from the start. Turkish has its own poetic logic.

### Pitfall 2: Overusing "Olmuş, Olmuş, Olmuş"
The past tense suffix "-mış/-miş" is grammatically correct but overusing it can sound monotonous. Vary verb tenses.

### Pitfall 3: Missing Object Particles
Turkish has accusative ("-i/-ı/-u/-ü"), dative ("-e/-a"), and locative ("-de/-da") particles. Missing these is grammatically wrong and sounds strange when sung.

### Pitfall 4: Sentence Fragments
Don't write fragmented phrases unless they're a deliberate stylistic choice. Complete sentences sing better.

## Theme and Emotion in Turkish Rock

Turkish rock has a rich tradition of certain emotional territories:

- **Yas (mourning):** Loss, grief, lingering sadness
- **Hasret (longing):** Yearning for someone or something distant
- **İçsel hesaplaşma (inner reckoning):** Self-confrontation, regret, growth
- **Yalnızlık (loneliness):** Solitude, isolation, existential weight
- **Geçmişe özlem (nostalgia):** Missing the past, lost time, what was

These themes resonate naturally with Turkish listeners and align well with the rock genre's emotional vocabulary.

## Final Quality Check

Before finalizing Turkish lyrics:

1. Read out loud — does it flow naturally?
2. Check character simplification — any â/î/û remaining?
3. Check sentence structure — any devrik forms?
4. Check line length — any line over 8 words?
5. Check for clichés — any overused phrases?
6. Check imagery — is it concrete and specific?
7. Check rhyme — does any rhyme feel forced?

If all checks pass, the lyrics are ready for Suno generation.
