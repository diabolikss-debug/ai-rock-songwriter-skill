# Vocal Direction Guide

This document covers how to describe vocals for AI music generators effectively. Good vocal direction is the difference between a generic AI song and one with character.

## Why Vocal Direction Matters

AI generators like Suno produce vastly different vocals based on prompt direction. Generic prompts produce generic vocals. Specific, descriptive prompts produce vocals with character, emotional weight, and identity.

The goal is to direct the AI toward the vocal style that fits your song without naming specific singers (copyright safety).

## The Five Components of Vocal Description

Every vocal direction should include or address:

1. **Range:** Bass, baritone, tenor, alto, mezzo, soprano
2. **Gender (if relevant):** Male, female, or unspecified
3. **Texture:** Smooth, rough, raspy, gritty, clean, breathy
4. **Delivery:** Restrained, powerful, intimate, anthemic, vulnerable
5. **Emotional quality:** Soulful, angry, melancholic, hopeful, weary

## Vocal Templates by Subgenre

### Classic Rock (1970s)

```
Baritone male vocals with raw emotional weight, gritty mid-range with bluesy 
phrasing, no vocal acrobatics, classic rock vocal craft, slightly weathered 
texture, controlled but expressive delivery
```

### Hard Rock

```
Powerful tenor or baritone male vocals, controlled grit, anthemic delivery, 
strong lower register with melodic upper reach, classic rock vocal projection, 
not theatrical but powerful
```

### Doom Metal

```
Deep baritone male vocals with monolithic resonance, slow controlled delivery, 
sometimes growling but always intelligible, ritualistic and heavy vocal weight, 
not screamed, atmospheric and looming
```

### Stoner Rock

```
Mid-range male vocals with desert grit, slightly drawled delivery, fuzzy 
production on the vocal track, hypnotic phrasing, occasional vocal effects 
like phaser or chorus, warm and slightly stoned-sounding
```

### Post-Rock (When Vocals Appear)

```
Soft melodic vocals buried in atmospheric mix, ethereal quality, often 
whispered or sung at low volume, reverb-drenched, fragmentary phrases, 
not performative
```

### Punk Rock

```
Shouted male vocals with attitude, raw and untrained, urgent delivery, 
not melodic in traditional sense, snotty and confrontational, lo-fi 
vocal production, distorted edges
```

### Grunge

```
Baritone male vocals with vocal cracks and emotional strain, melodic but 
anguished, alternates between intimate verses and powerful choruses, 
Pacific Northwest grunge vocal aesthetic, raw and unpolished, 
deliberately imperfect delivery
```

### Post-Grunge Ballad

```
Baritone male vocals with rich resonance and emotional depth, soulful and 
slightly haunting with smooth melodic phrasing, builds from hushed intimate 
delivery to anguished cathartic climax, controlled but emotionally present
```

### Alternative Indie

```
Tenor or baritone male vocals with reverb, conversational delivery, 
introspective tone, slightly nasal in indie tradition, melodic but 
restrained, mid-1990s college rock vocal aesthetic
```

### Garage Rock

```
Snotty mid-range male vocals through tape echo, primitive delivery, 
energetic but not technically polished, mono recording aesthetic, 
attitude over technique
```

### Shoegaze

```
Soft ethereal vocals buried in wall of sound, dreamy delivery, often 
whispered or sung at low intensity, gender-ambiguous quality acceptable, 
reverb-heavy production
```

## Specific Vocal Effect Descriptions

### Reverb and Space

```
Cathedral-sized reverb on vocals
Subtle plate reverb adding depth
Tight room reverb for intimacy
Tape echo on vocals
Heavy delay on chorus vocals
Dry vocals for direct intimacy
```

### Vocal Production Aesthetics

```
Lo-fi vocal production with tape compression
Clean modern vocal production
Vintage analog vocal warmth
Dirty distorted vocal channel
Crystal clear digital vocal
Crushed compression on vocals for punk energy
```

### Vocal Texture Modifiers

```
Vocal cracks and breaks for emotional honesty
Whispered ad-libs in outro
Backup vocals doubling main melody
Harmonized chorus vocals
Solo vocal throughout (no backups)
Layered vocal stacks for chorus impact
```

## Building Custom Vocal Descriptions

Combine elements to build descriptions that fit your specific song:

### Template:

```
[Range] [gender] vocals with [texture quality], [delivery style], 
[emotional quality], [production aesthetic], [specific effects if any]
```

### Examples:

For a melancholic post-grunge ballad:
```
Baritone male vocals with rich resonance, slow restrained delivery, 
soulful and slightly haunting, classic rock production with subtle reverb, 
vocal cracks in emotional moments
```

For an energetic punk track:
```
Mid-range male vocals with raw untrained quality, shouted delivery, 
urgent and confrontational, lo-fi distorted vocal channel, 
no effects beyond tape distortion
```

For an atmospheric post-rock piece:
```
Whispered male vocals with ethereal quality, sparse minimal delivery, 
fragmentary and dreamlike, heavy reverb production, 
buried in atmospheric mix
```

## Vocal Persona Strategy

Suno's Persona feature allows reuse of the same vocal across multiple songs. This is powerful for:

- Building a channel with consistent identity
- Creating an album feel across separate releases
- Establishing audience recognition

### How to use Personas:

1. Generate the first song with your standard vocal description
2. When you find a generation with the right vocal character, save it as a Persona
3. Name the Persona descriptively (e.g., "TRK-Baritone-1" or "Channel-Vocal-Main")
4. Use the same Persona for subsequent songs
5. The vocal description in the prompt becomes secondary to the Persona's locked character

### When to use different Personas:

- Side projects or sub-brands within the same channel
- Drastically different subgenres (e.g., punk vs. doom)
- Featured artist or collaboration concepts
- Special releases with different vocal identity

For most channels, one or two Personas is enough.

## Female Vocal Considerations

When directing female vocals:

```
Female alto vocals with warm tone, controlled emotional delivery, 
mid-range power, rock-grounded vocal craft not pop-styled
```

```
Female mezzo-soprano with strong projection, grungy edge, 
vulnerable but powerful, alt-rock vocal aesthetic
```

```
Soft female vocals with breathy quality, intimate delivery, 
indie folk-rock vocal aesthetic with restrained emotion
```

## Avoiding Common Vocal Direction Mistakes

### Mistake 1: Too Generic

Bad: "Male vocals"
Good: "Baritone male vocals with raw emotional weight and vocal cracks"

### Mistake 2: Naming Specific Artists

Bad: "Vocals like [Singer Name]"
Good: "Soulful baritone with rich resonance, classic rock vocal craft"

This is a copyright safety issue and produces less original results.

### Mistake 3: Contradictory Direction

Bad: "Polished raw vocals with controlled chaos"
Good: "Controlled vocals with subtle grit and emotional restraint"

Contradictions confuse the AI and produce inconsistent results.

### Mistake 4: Over-Direction

Bad: "Baritone male vocals with raspy texture, slightly nasal, gritty mid-range, vocal cracks, breath sounds, slight vibrato, occasional falsetto, anguished delivery, controlled power, intimate verses, anthemic choruses, vulnerable bridges, climactic finale"

Good: "Baritone male vocals with raw emotional weight, builds from intimate to anguished cathartic delivery"

Less is more. The AI fills in details based on context.

### Mistake 5: Wrong Range for Genre

Bad: "Soprano female vocals for doom metal"
Good: "Deep baritone male vocals for doom metal" or "Powerful contralto female vocals for doom metal"

Match the vocal range to genre conventions for natural results.

## Testing Vocal Output

When you receive Suno's first generation:

1. **Range check:** Is the voice in the expected range?
2. **Gender check:** Did the AI interpret the gender correctly?
3. **Texture check:** Does the voice have the desired roughness or smoothness?
4. **Emotion check:** Does the delivery feel emotionally appropriate?
5. **Genre fit:** Does the vocal style match the subgenre?

If any check fails, adjust one element of the vocal direction at a time and regenerate. Don't change everything at once; isolate variables.

## Special Cases

### When the AI keeps producing the wrong gender vocal:

Add explicit reinforcement:
```
Male vocals only, no female vocals, baritone range
```

### When the vocal is too polished:

```
Raw unpolished vocal delivery, deliberately imperfect, vocal cracks acceptable, 
not pop-produced, lo-fi vocal aesthetic
```

### When the vocal is too raw:

```
Controlled but emotional vocal delivery, melodic phrasing, 
classic rock vocal craft with restraint
```

### When you want a specific vocal character but can't describe it:

Try metaphors:
```
Voice that sounds like it's been smoking for thirty years
Voice that sounds like a confession in an empty room
Voice that sounds like crying that's been held back
```

These metaphorical descriptions sometimes produce surprising and effective results.

## Final Vocal Direction Checklist

Before finalizing your vocal direction:

1. Does it specify range and gender (if relevant)?
2. Does it describe texture and delivery?
3. Does it convey emotional quality?
4. Does it fit the subgenre conventions?
5. Does it avoid naming specific artists?
6. Is it specific without being over-directed?
7. Will it produce consistent results across multiple generations?

If all checks pass, the vocal direction is ready.
